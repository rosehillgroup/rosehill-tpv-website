/**
 * Rosehill TPV® Colour Mixer Application
 * React-based interactive color mixing tool
 */

(function() {
    'use strict';

    // Wait for DOM to be ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initMixer);
    } else {
        initMixer();
    }

    function initMixer() {
        // Check required dependencies
        if (typeof React === 'undefined') {
            console.error('Rosehill Mixer: React is not loaded');
            showError('React library not found. Please contact support.');
            return;
        }

        if (typeof ReactDOM === 'undefined') {
            console.error('Rosehill Mixer: ReactDOM is not loaded');
            showError('ReactDOM library not found. Please contact support.');
            return;
        }

        if (typeof d3 === 'undefined') {
            console.error('Rosehill Mixer: D3 Delaunay is not loaded');
            showError('D3 Delaunay library not found. Please contact support.');
            return;
        }

        if (typeof THREE === 'undefined') {
            console.error('Rosehill Mixer: Three.js is not loaded');
            showError('Three.js library not found. Please contact support.');
            return;
        }

        if (typeof jspdf === 'undefined' && typeof window.jspdf === 'undefined') {
            console.error('Rosehill Mixer: jsPDF is not loaded');
            // PDF export will fail but mixer can still work
        }

        // Check for container
        const container = document.getElementById('rosehill-tpv-mixer-root');
        if (!container) {
            console.error('Rosehill Mixer: Container element not found');
            return;
        }

        // Initialize the mixer
        try {
            startMixerApp(container);
        } catch (error) {
            console.error('Rosehill Mixer: Initialization error', error);
            showError('Failed to initialize mixer. Please refresh the page.');
        }
    }

    function showError(message) {
        const container = document.getElementById('rosehill-tpv-mixer-root');
        if (container) {
            container.innerHTML = '<div style="padding: 40px; text-align: center; background: #fee; border: 2px solid #fcc; border-radius: 8px; color: #c33;"><h3>Error</h3><p>' + message + '</p></div>';
        }
    }

    function startMixerApp(container) {
        // Predefined colour palette - Rosehill TPV® colours
        const PALETTE = [
            { name: 'Beige', code: 'RH30', hex: '#E4C4AA' },
            { name: 'Cream', code: 'RH31', hex: '#E8E3D8' },
            { name: 'Bright Yellow', code: 'RH41', hex: '#FFD833' },
            { name: 'Mustard', code: 'RH40', hex: '#E5A144' },
            { name: 'Orange', code: 'RH50', hex: '#F15B32' },
            { name: 'Standard Red', code: 'RH01', hex: '#A5362F' },
            { name: 'Bright Red', code: 'RH02', hex: '#E21F2F' },
            { name: 'Funky Pink', code: 'RH90', hex: '#E8457E' },
            { name: 'Purple', code: 'RH21', hex: '#493D8C' },
            { name: 'Standard Blue', code: 'RH20', hex: '#0075BC' },
            { name: 'Light Blue', code: 'RH22', hex: '#47AFE3' },
            { name: 'Azure', code: 'RH23', hex: '#039DC4' },
            { name: 'Turquoise', code: 'RH26', hex: '#00A6A3' },
            { name: 'Dark Green', code: 'RH12', hex: '#006C55' },
            { name: 'Standard Green', code: 'RH10', hex: '#609B63' },
            { name: 'Bright Green', code: 'RH11', hex: '#3BB44A' },
            { name: 'Brown', code: 'RH32', hex: '#8B5F3C' },
            { name: 'Pale Grey', code: 'RH65', hex: '#D9D9D6' },
            { name: 'Light Grey', code: 'RH61', hex: '#939598' },
            { name: 'Dark Grey', code: 'RH60', hex: '#59595B' },
            { name: 'Black', code: 'RH70', hex: '#231F20' }
        ];

        // React hooks
        const { useState, useEffect, useRef, useCallback, useMemo } = React;

            // Simple seedable PRNG
            function mulberry32(a) {
                return function() {
                    let t = a += 0x6D2B79F5;
                    t = Math.imul(t ^ t >>> 15, t | 1);
                    t ^= t + Math.imul(t ^ t >>> 7, t | 61);
                    return ((t ^ t >>> 14) >>> 0) / 4294967296;
                };
            }

            // Poisson disk sampling
            function poissonDiskSampling(width, height, minDistance, maxTries = 30, rng = Math.random) {
                const cellSize = minDistance / Math.sqrt(2);
                const gridWidth = Math.ceil(width / cellSize);
                const gridHeight = Math.ceil(height / cellSize);
                const grid = new Array(gridWidth * gridHeight).fill(-1);
                const points = [];
                const activeList = [];

                function addPoint(x, y) {
                    const point = [x, y];
                    points.push(point);
                    const gridX = Math.floor(x / cellSize);
                    const gridY = Math.floor(y / cellSize);
                    grid[gridY * gridWidth + gridX] = points.length - 1;
                    activeList.push(points.length - 1);
                    return point;
                }

                function inNeighbourhood(x, y) {
                    const gridX = Math.floor(x / cellSize);
                    const gridY = Math.floor(y / cellSize);

                    for (let i = Math.max(0, gridX - 2); i <= Math.min(gridWidth - 1, gridX + 2); i++) {
                        for (let j = Math.max(0, gridY - 2); j <= Math.min(gridHeight - 1, gridY + 2); j++) {
                            const idx = grid[j * gridWidth + i];
                            if (idx !== -1) {
                                const dx = x - points[idx][0];
                                const dy = y - points[idx][1];
                                if (dx * dx + dy * dy < minDistance * minDistance) {
                                    return true;
                                }
                            }
                        }
                    }
                    return false;
                }

                // Add first point
                addPoint(width * rng(), height * rng());

                while (activeList.length > 0) {
                    const randomIndex = Math.floor(rng() * activeList.length);
                    const pointIndex = activeList[randomIndex];
                    const point = points[pointIndex];
                    let found = false;

                    for (let tries = 0; tries < maxTries; tries++) {
                        const angle = 2 * Math.PI * rng();
                        const radius = minDistance + minDistance * rng();
                        const x = point[0] + radius * Math.cos(angle);
                        const y = point[1] + radius * Math.sin(angle);

                        if (x >= 0 && x < width && y >= 0 && y < height && !inNeighbourhood(x, y)) {
                            addPoint(x, y);
                            found = true;
                            break;
                        }
                    }

                    if (!found) {
                        activeList.splice(randomIndex, 1);
                    }
                }

                return points;
            }

            // Generate a shareable seed
            function generateSeed() {
                return Math.random().toString(36).substring(2, 10);
            }

            // HSL color conversion utilities for color variation
            function rgbToHsl(r, g, b) {
                r /= 255; g /= 255; b /= 255;
                const max = Math.max(r, g, b), min = Math.min(r, g, b);
                let h, s, l = (max + min) / 2;

                if (max === min) {
                    h = s = 0; // achromatic
                } else {
                    const d = max - min;
                    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
                    switch (max) {
                        case r: h = (g - b) / d + (g < b ? 6 : 0); break;
                        case g: h = (b - r) / d + 2; break;
                        case b: h = (r - g) / d + 4; break;
                    }
                    h /= 6;
                }
                return [h * 360, s, l];
            }

            function hslToRgb(h, s, l) {
                function hue2rgb(p, q, t) {
                    if (t < 0) t += 1;
                    if (t > 1) t -= 1;
                    if (t < 1/6) return p + (q - p) * 6 * t;
                    if (t < 1/2) return q;
                    if (t < 2/3) return p + (q - p) * (2/3 - t) * 6;
                    return p;
                }

                if (s === 0) {
                    return [l * 255, l * 255, l * 255]; // achromatic
                } else {
                    const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
                    const p = 2 * l - q;
                    const r = hue2rgb(p, q, h + 1/3);
                    const g = hue2rgb(p, q, h);
                    const b = hue2rgb(p, q, h - 1/3);
                    return [r * 255, g * 255, b * 255];
                }
            }

            // Base36 encoding/decoding for compact codes
            function encodeBase36(num) {
                return num.toString(36).toUpperCase();
            }

            function decodeBase36(str) {
                return parseInt(str, 36);
            }

            // Compress recipe data
            function compressRecipe(parts) {
                if (parts.size === 0) return '';
                return Array.from(parts.entries())
                    .map(([colourIndex, count]) => `${encodeBase36(colourIndex)}${encodeBase36(count)}`)
                    .join('');
            }

            function decompressRecipe(compressed) {
                if (!compressed) return new Map();
                const parts = new Map();
                // Parse pairs of base36 characters
                for (let i = 0; i < compressed.length; i += 2) {
                    if (i + 1 < compressed.length) {
                        const colourIndex = decodeBase36(compressed[i]);
                        const count = decodeBase36(compressed[i + 1]);
                        if (!isNaN(colourIndex) && !isNaN(count) && colourIndex >= 0 && colourIndex < PALETTE.length) {
                            parts.set(colourIndex, count);
                        }
                    }
                }
                return parts;
            }

            // 3D Tile Preview Component
            function TilePreview({ canvasRef, parts, totalParts }) {
                const tileContainerRef = useRef(null);
                const tileSceneRef = useRef(null);
                const [tileLoading, setTileLoading] = useState(false);
                const [tileError, setTileError] = useState(null);
                const [tileZoomLevel, setTileZoomLevel] = useState(1);

                // Initialize 3D scene
                useEffect(() => {
                    if (!tileContainerRef.current || typeof THREE === 'undefined') {
                        setTileError('3D not supported in this browser');
                        return;
                    }

                    // OrbitControls should now be available as we embedded it
                    if (!THREE.OrbitControls) {
                        setTileError('3D controls initialization failed');
                        return;
                    }
                    const OrbitControls = THREE.OrbitControls;

                    // Check WebGL support
                    const canvas = document.createElement('canvas');
                    const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
                    if (!gl) {
                        setTileError('WebGL not supported in this browser');
                        return;
                    }

                    try {
                        // Scene setup
                        const scene = new THREE.Scene();
                        scene.background = new THREE.Color(0xf5f5f5);

                        // Camera setup
                        const camera = new THREE.PerspectiveCamera(
                            50,
                            tileContainerRef.current.clientWidth / tileContainerRef.current.clientHeight,
                            0.1,
                            1000
                        );
                        camera.position.set(300, 200, 300);

                        // Renderer setup with enhanced settings
                        const renderer = new THREE.WebGLRenderer({ 
                            antialias: true, 
                            alpha: true,
                            powerPreference: "high-performance"
                        });
                        renderer.setSize(
                            tileContainerRef.current.clientWidth,
                            tileContainerRef.current.clientHeight
                        );
                        renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2)); // Limit for performance
                        renderer.shadowMap.enabled = true;
                        renderer.shadowMap.type = THREE.PCFSoftShadowMap;
                        renderer.outputEncoding = THREE.sRGBEncoding;
                        
                        // Renderer settings optimized for vibrant colors
                        renderer.physicallyCorrectLights = false; // Disable for more predictable lighting
                        renderer.toneMapping = THREE.ReinhardToneMapping; // Better for vibrant colors
                        renderer.toneMappingExposure = 1.1; // Higher exposure for color pop

                        tileContainerRef.current.appendChild(renderer.domElement);

                        // Enhanced lighting setup for realistic rubber tile appearance
                        
                        // 1. Ambient light - brighter for vibrant colors
                        const ambientLight = new THREE.AmbientLight(0xffffff, 0.5); // Much brighter for color vibrancy
                        scene.add(ambientLight);

                        // 2. Main directional light - bright enough to show true colors
                        const mainLight = new THREE.DirectionalLight(0xffffff, 0.4); // Brighter for color pop
                        mainLight.position.set(400, 500, 300);
                        mainLight.castShadow = true;
                        mainLight.shadow.mapSize.width = 2048;
                        mainLight.shadow.mapSize.height = 2048;
                        mainLight.shadow.camera.near = 0.1;
                        mainLight.shadow.camera.far = 1000;
                        mainLight.shadow.camera.left = -300;
                        mainLight.shadow.camera.right = 300;
                        mainLight.shadow.camera.top = 300;
                        mainLight.shadow.camera.bottom = -300;
                        mainLight.shadow.bias = -0.0001;
                        scene.add(mainLight);

                        // 3. Fill light - stronger fill for color vibrancy
                        const fillLight = new THREE.DirectionalLight(0xffffff, 0.15); // More visible
                        fillLight.position.set(-200, 250, -150);
                        scene.add(fillLight);

                        // 4. Rim light - stronger edge definition for pop
                        const rimLight = new THREE.DirectionalLight(0xffffff, 0.2); // Stronger rim lighting
                        rimLight.position.set(-250, 200, 400);
                        scene.add(rimLight);

                        // Remove point light and hemisphere light - too much brightness
                        // Focus on color accuracy for UV-stable TPV presentation

                        // Tile geometry (200x200x20mm - realistic size)
                        const geometry = new THREE.BoxGeometry(200, 20, 200);
                        
                        // Basic material (will be updated with texture)
                        const material = new THREE.MeshStandardMaterial({
                            color: 0xfafafa,
                            roughness: 0.8,
                            metalness: 0.1
                        });

                        const tile = new THREE.Mesh(geometry, material);
                        tile.castShadow = true;
                        tile.receiveShadow = true;
                        scene.add(tile);

                        // Ground plane for shadows
                        const groundGeometry = new THREE.PlaneGeometry(800, 800);
                        const groundMaterial = new THREE.ShadowMaterial({ opacity: 0.2 });
                        const ground = new THREE.Mesh(groundGeometry, groundMaterial);
                        ground.rotation.x = -Math.PI / 2;
                        ground.position.y = -10; // Half the tile height (20mm/2)
                        ground.receiveShadow = true;
                        scene.add(ground);

                        // Controls
                        const controls = new OrbitControls(camera, renderer.domElement);
                        controls.enableDamping = true;
                        controls.dampingFactor = 0.1;
                        controls.target.set(0, 0, 0);
                        controls.maxDistance = 800;
                        controls.minDistance = 150;

                        // Store scene references including lights for animation
                        tileSceneRef.current = {
                            scene,
                            camera,
                            renderer,
                            controls,
                            tile,
                            material,
                            lights: {
                                main: mainLight,
                                fill: fillLight,
                                rim: rimLight
                            },
                            isAnimating: true
                        };

                        // Animation loop with smart updates
                        let lastInteractionTime = Date.now();
                        let animationTime = 0;
                        let lastFrameTime = Date.now();
                        let isUserControlling = false;
                        
                        const animate = () => {
                            if (tileSceneRef.current && tileSceneRef.current.isAnimating) {
                                const now = Date.now();
                                const deltaTime = now - lastFrameTime;
                                lastFrameTime = now;
                                
                                animationTime += deltaTime * 0.001; // Convert to seconds
                                
                                // Check if user is actively controlling
                                const timeSinceInteraction = now - lastInteractionTime;
                                isUserControlling = timeSinceInteraction < 100; // 100ms threshold
                                
                                // Update controls - this now returns whether an update was applied
                                const controlsUpdated = controls.update();
                                
                                // Check if material needs updating (texture changes)
                                const materialNeedsUpdate = tileSceneRef.current.material && tileSceneRef.current.material.needsUpdate;
                                
                                let sceneChanged = controlsUpdated || materialNeedsUpdate;
                                
                                // Only apply auto-rotation if user isn't controlling and sufficient time has passed
                                if (!isUserControlling && timeSinceInteraction > 3000) { // 3 seconds of no interaction  
                                    tile.rotation.y += 0.003; // Slower rotation
                                    sceneChanged = true;
                                }
                                
                                // Always update subtle lighting animation
                                const { lights } = tileSceneRef.current;

                                // Lighting animation for vibrant appearance
                                // Gentle intensity variation to maintain vibrancy
                                lights.main.intensity = 0.4 + Math.sin(animationTime * 0.2) * 0.03;
                                lights.rim.intensity = 0.2 + Math.cos(animationTime * 0.25) * 0.015;
                                
                                // Only render if something changed
                                if (sceneChanged) {
                                    renderer.render(scene, camera);
                                }
                                
                                requestAnimationFrame(animate);
                            }
                        };
                        
                        // Track user interactions to pause auto-rotation
                        const updateInteractionTime = () => { lastInteractionTime = Date.now(); };
                        renderer.domElement.addEventListener('mousedown', updateInteractionTime);
                        renderer.domElement.addEventListener('touchstart', updateInteractionTime);
                        renderer.domElement.addEventListener('wheel', updateInteractionTime);
                        animate();

                        // Handle resize
                        const handleResize = () => {
                            if (tileContainerRef.current && tileSceneRef.current) {
                                const width = tileContainerRef.current.clientWidth;
                                const height = tileContainerRef.current.clientHeight;
                                
                                camera.aspect = width / height;
                                camera.updateProjectionMatrix();
                                renderer.setSize(width, height);
                            }
                        };

                        window.addEventListener('resize', handleResize);

                        return () => {
                            window.removeEventListener('resize', handleResize);
                            if (tileSceneRef.current) {
                                tileSceneRef.current.isAnimating = false;
                                if (tileContainerRef.current && renderer.domElement) {
                                    tileContainerRef.current.removeChild(renderer.domElement);
                                }
                                renderer.dispose();
                                geometry.dispose();
                                material.dispose();
                                controls.dispose();
                            }
                        };

                    } catch (error) {
                        console.error('3D initialization error:', error);
                        setTileError('Failed to initialize 3D preview');
                    }
                }, []);

                // Create distance-optimized tile surface using enhanced Voronoi
                const createTileSurface = useCallback((parts, tileSize = 512) => {
                    if (!parts || parts.size === 0) return null;

                    const canvas = document.createElement('canvas');
                    const ctx = canvas.getContext('2d');
                    canvas.width = tileSize;
                    canvas.height = tileSize;

                    // Calculate total parts for distribution
                    const totalParts = Array.from(parts.values()).reduce((a, b) => a + b, 0);
                    if (totalParts === 0) return null;

                    // Balanced tile settings - realistic granule size with optimized performance
                    const numPoints = Math.floor(tileSize * tileSize / 60); // ~4,500 granules for 512px - realistic size, good performance
                    const points = [];

                    // Generate points using enhanced Poisson disk sampling
                    const baseMinDistance = Math.sqrt(60) * 0.75; // Smaller granules for realistic appearance
                    let attempts = 0;
                    const maxAttempts = numPoints * 50;

                    // Use fixed seed for consistent tile generation
                    const tileSeed = 'tile_surface_' + Array.from(parts.entries()).map(([k,v]) => `${k}:${v}`).join('_');
                    const seedNum = tileSeed.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
                    const tileRng = mulberry32(seedNum);

                    while (points.length < numPoints && attempts < maxAttempts) {
                        const x = tileRng() * tileSize;
                        const y = tileRng() * tileSize;

                        // Check minimum distance with clustering variation
                        const maxTries = 20 + Math.floor(tileRng() * 20); // 20-40 variation
                        const minDistance = baseMinDistance * (0.8 + tileRng() * 0.4); // Distance variation

                        let validPoint = true;
                        for (let i = 0; i < points.length; i++) {
                            const distance = Math.sqrt((points[i].x - x) ** 2 + (points[i].y - y) ** 2);
                            if (distance < minDistance) {
                                validPoint = false;
                                break;
                            }
                        }

                        if (validPoint) {
                            // Enhanced size distribution for distance viewing (25%-400% range)
                            const sizeRng1 = tileRng();
                            const sizeRng2 = tileRng();
                            const sizeRng3 = tileRng();
                            const weightedRandom = (sizeRng1 + sizeRng2 + sizeRng3) / 3; // Bell curve
                            const exponentialWeight = Math.pow(weightedRandom, 1.5); // Favor medium sizes
                            const granuleSize = 0.25 + exponentialWeight * 3.75; // 25%-400% range

                            points.push({ x, y, size: granuleSize });
                        }
                        attempts++;
                    }

                    // Generate Delaunay triangulation and Voronoi cells
                    const delaunay = d3.Delaunay.from(points, d => d.x, d => d.y);
                    const voronoi = delaunay.voronoi([0, 0, tileSize, tileSize]);

                    // Assign colors to cells based on parts distribution
                    const cellAssignments = new Array(points.length).fill(-1);
                    const indices = Array.from({ length: points.length }, (_, i) => i);

                    // Fisher-Yates shuffle for randomization
                    for (let i = indices.length - 1; i > 0; i--) {
                        const j = Math.floor(tileRng() * (i + 1));
                        [indices[i], indices[j]] = [indices[j], indices[i]];
                    }

                    // Assign colors based on parts
                    let cursor = 0;
                    parts.forEach((partCount, colourIndex) => {
                        const quota = Math.round((partCount / totalParts) * indices.length);
                        for (let i = 0; i < quota && cursor < indices.length; i++) {
                            cellAssignments[indices[cursor]] = colourIndex;
                            cursor++;
                        }
                    });

                    // Render the tile surface with all realism enhancements
                    // First pass: Base colors with enhanced variations
                    for (let i = 0; i < points.length; i++) {
                        const colourIndex = cellAssignments[i];
                        if (colourIndex === -1) continue;

                        const cell = voronoi.cellPolygon(i);
                        if (!cell || cell.length < 3) continue;

                        const baseColour = PALETTE[colourIndex];
                        const variationRng = mulberry32(Math.floor(points[i].x + points[i].y * 1000));

                        // Parse base color and apply enhanced variations
                        const r = parseInt(baseColour.hex.slice(1, 3), 16);
                        const g = parseInt(baseColour.hex.slice(3, 5), 16);
                        const b = parseInt(baseColour.hex.slice(5, 7), 16);

                        const hsl = rgbToHsl(r, g, b);

                        // Color family detection for smart enhancements
                        const isLightColor = hsl[2] > 0.6; // Light colors (yellows, whites, light blues, etc.)
                        const isDarkColor = hsl[2] < 0.3;  // Dark colors (blacks, dark reds, etc.)
                        const isVibrantColor = hsl[1] > 0.7; // Already saturated colors

                        // Enhanced variations based on color family
                        let satVariation, hueVariation, lightVariation;

                        if (isLightColor) {
                            // Light colors: boost saturation significantly, subtle hue shifts
                            satVariation = (variationRng() - 0.5) * 0.15 + 0.1; // +10% base boost
                            hueVariation = (variationRng() - 0.5) * 3;
                            lightVariation = (variationRng() - 0.5) * 0.08;
                        } else if (isDarkColor) {
                            // Dark colors: enhance contrast, maintain depth
                            satVariation = (variationRng() - 0.5) * 0.12;
                            hueVariation = (variationRng() - 0.5) * 5;
                            lightVariation = (variationRng() - 0.5) * 0.1; // More light variation for depth
                        } else {
                            // Mid-tone colors: balanced enhancement
                            satVariation = (variationRng() - 0.5) * 0.13;
                            hueVariation = (variationRng() - 0.5) * 4;
                            lightVariation = (variationRng() - 0.5) * 0.08;
                        }

                        const newSat = Math.max(0, Math.min(1, hsl[1] + satVariation));
                        const newHue = (hsl[0] + hueVariation + 360) % 360;
                        let newLight = Math.max(0, Math.min(1, hsl[2] + lightVariation));

                        // Smart size-based hierarchy - much less aggressive muting
                        const granuleSize = points[i].size;
                        const normalizedSize = Math.min(4, Math.max(0.25, granuleSize));
                        const sizeContrastFactor = 0.85 + (normalizedSize / 4) * 0.3; // Less extreme range
                        let contrastAdjustedSat = Math.max(0, Math.min(1, newSat * sizeContrastFactor));

                        // Greatly reduced muting for small granules - keep them vibrant!
                        if (normalizedSize < 1.0 && !isLightColor) {
                            // Only mute dark colors slightly, preserve light color vibrancy
                            const muteFactor = (1.0 - normalizedSize) * 0.1; // Reduced from 0.3
                            newLight = newLight + (0.4 - newLight) * muteFactor; // Less gray (0.4 instead of 0.5)
                        }

                        // Extra boost for light colors to make them pop
                        if (isLightColor && normalizedSize > 0.8) {
                            contrastAdjustedSat = Math.min(1, contrastAdjustedSat * 1.15); // 15% saturation boost
                            newLight = Math.min(1, newLight * 1.05); // Slight brightness boost
                        }

                        const [finalR, finalG, finalB] = hslToRgb(newHue / 360, contrastAdjustedSat, newLight);
                        const finalColor = `rgb(${Math.round(finalR)}, ${Math.round(finalG)}, ${Math.round(finalB)})`;

                        // Draw the cell
                        ctx.fillStyle = finalColor;
                        ctx.beginPath();
                        ctx.moveTo(cell[0][0], cell[0][1]);
                        for (let j = 1; j < cell.length; j++) {
                            ctx.lineTo(cell[j][0], cell[j][1]);
                        }
                        ctx.closePath();
                        ctx.fill();
                    }

                    // Second pass: Enhanced 3D lighting and surface effects
                    for (let i = 0; i < points.length; i++) {
                        const colourIndex = cellAssignments[i];
                        if (colourIndex === -1) continue;

                        const cell = voronoi.cellPolygon(i);
                        if (!cell || cell.length < 3) continue;

                        const granuleSize = points[i].size;
                        const normalizedSize = Math.min(4, Math.max(0.25, granuleSize));

                        // Calculate cell bounds for lighting
                        let minX = cell[0][0], maxX = cell[0][0];
                        let minY = cell[0][1], maxY = cell[0][1];
                        let centerX = 0, centerY = 0;

                        for (let j = 0; j < cell.length; j++) {
                            minX = Math.min(minX, cell[j][0]);
                            maxX = Math.max(maxX, cell[j][0]);
                            minY = Math.min(minY, cell[j][1]);
                            maxY = Math.max(maxY, cell[j][1]);
                            centerX += cell[j][0];
                            centerY += cell[j][1];
                        }
                        centerX /= cell.length;
                        centerY /= cell.length;

                        // Enhanced lighting simulation for tile surface
                        const width = maxX - minX;
                        const height = maxY - minY;
                        const radius = Math.max(width, height) / 2;

                        // Multiple light sources for realism
                        const lightDir1 = { x: -0.7071, y: -0.7071 }; // Top-left primary
                        const lightDir2 = { x: 0.5, y: -0.8 }; // Top-right rim

                        // Create radial gradient for 3D effect
                        const gradient = ctx.createRadialGradient(centerX, centerY, 0, centerX, centerY, radius);

                        // Calculate lighting based on granule size and position
                        const lightIntensity1 = Math.max(0, -lightDir1.x * 0.3 + -lightDir1.y * 0.7) * 0.8;
                        const lightIntensity2 = Math.max(0, lightDir2.x * 0.3 + -lightDir2.y * 0.7) * 0.3;
                        const totalLighting = 0.2 + lightIntensity1 + lightIntensity2; // 20% ambient

                        // Size-based lighting variation
                        const lightingBoost = 0.9 + (normalizedSize / 4) * 0.2; // Large granules get more light
                        const finalLighting = Math.min(1.2, totalLighting * lightingBoost);

                        // Ambient occlusion for depth
                        const occlusion = Math.max(0, 1 - (normalizedSize / 4) * 0.15); // Large granules get slight darkening

                        const lightColor = `rgba(255, 255, 255, ${finalLighting * 0.15})`;
                        const shadowColor = `rgba(0, 0, 0, ${(1 - occlusion) * 0.1})`;

                        gradient.addColorStop(0, lightColor);
                        gradient.addColorStop(0.7, 'rgba(255, 255, 255, 0)');
                        gradient.addColorStop(1, shadowColor);

                        // Apply gradient within cell bounds
                        ctx.save();
                        ctx.beginPath();
                        ctx.moveTo(cell[0][0], cell[0][1]);
                        for (let j = 1; j < cell.length; j++) {
                            ctx.lineTo(cell[j][0], cell[j][1]);
                        }
                        ctx.closePath();
                        ctx.clip();

                        ctx.fillStyle = gradient;
                        ctx.fill();
                        ctx.restore();

                        // Add specular highlights for large granules (distance-appropriate)
                        if (normalizedSize > 2.0 && finalLighting > 1.0) {
                            const highlightIntensity = (finalLighting - 1.0) * (normalizedSize / 4) * 0.8;
                            ctx.fillStyle = `rgba(255, 255, 255, ${Math.min(0.4, highlightIntensity)})`;
                            ctx.beginPath();
                            ctx.arc(
                                centerX - radius * 0.2,
                                centerY - radius * 0.2,
                                radius * 0.3,
                                0,
                                Math.PI * 2
                            );
                            ctx.fill();
                        }
                    }

                    return canvas;
                }, []);

                // Create enhanced bump map from granule structure
                const createEnhancedBumpMap = useCallback((parts, size = 256) => {
                    const bumpCanvas = document.createElement('canvas');
                    const bumpCtx = bumpCanvas.getContext('2d');
                    bumpCanvas.width = size;
                    bumpCanvas.height = size;

                    if (!parts || parts.size === 0) {
                        // Fill with neutral gray for no bump effect
                        bumpCtx.fillStyle = '#808080';
                        bumpCtx.fillRect(0, 0, size, size);
                        return bumpCanvas;
                    }

                    // Generate granule structure for bump mapping to match realistic tile scale
                    const numPoints = Math.floor(size * size / 60); // Match main tile granule density for consistency
                    const points = [];

                    // Use same seed as tile surface for consistency
                    const totalParts = Array.from(parts.values()).reduce((a, b) => a + b, 0);
                    const tileSeed = 'bump_surface_' + Array.from(parts.entries()).map(([k,v]) => `${k}:${v}`).join('_');
                    const seedNum = tileSeed.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
                    const bumpRng = mulberry32(seedNum);

                    const baseMinDistance = Math.sqrt(60) * 0.75; // Match main tile scale for consistency
                    let attempts = 0;
                    const maxAttempts = numPoints * 50;

                    while (points.length < numPoints && attempts < maxAttempts) {
                        const x = bumpRng() * size;
                        const y = bumpRng() * size;
                        const minDistance = baseMinDistance * (0.8 + bumpRng() * 0.4);

                        let validPoint = true;
                        for (let i = 0; i < points.length; i++) {
                            const distance = Math.sqrt((points[i].x - x) ** 2 + (points[i].y - y) ** 2);
                            if (distance < minDistance) {
                                validPoint = false;
                                break;
                            }
                        }

                        if (validPoint) {
                            const sizeRng1 = bumpRng();
                            const sizeRng2 = bumpRng();
                            const sizeRng3 = bumpRng();
                            const weightedRandom = (sizeRng1 + sizeRng2 + sizeRng3) / 3;
                            const exponentialWeight = Math.pow(weightedRandom, 1.5);
                            const granuleSize = 0.25 + exponentialWeight * 3.75;

                            // Height varies with granule size for realistic bump mapping
                            const height = 0.3 + (granuleSize / 4) * 0.4; // 0.3-0.7 height range

                            points.push({ x, y, size: granuleSize, height: height });
                        }
                        attempts++;
                    }

                    // Generate Delaunay triangulation for height mapping
                    const delaunay = d3.Delaunay.from(points, d => d.x, d => d.y);
                    const voronoi = delaunay.voronoi([0, 0, size, size]);

                    // Create height map from granule structure
                    const imageData = bumpCtx.createImageData(size, size);
                    const data = imageData.data;

                    for (let y = 0; y < size; y++) {
                        for (let x = 0; x < size; x++) {
                            const index = (y * size + x) * 4;

                            // Find closest granule center for height information
                            let minDistance = Infinity;
                            let closestPoint = null;

                            for (let i = 0; i < points.length; i++) {
                                const distance = Math.sqrt((points[i].x - x) ** 2 + (points[i].y - y) ** 2);
                                if (distance < minDistance) {
                                    minDistance = distance;
                                    closestPoint = points[i];
                                }
                            }

                            if (closestPoint) {
                                // Calculate height based on distance to granule center (realistic scale)
                                const granuleRadius = Math.sqrt(60) * closestPoint.size * 0.5;
                                const distanceRatio = Math.min(1, minDistance / granuleRadius);

                                // Create raised granule profile (dome-like)
                                const heightProfile = Math.cos(distanceRatio * Math.PI * 0.5);
                                const finalHeight = 0.5 + (closestPoint.height * heightProfile * 0.5);

                                // Add subtle surface texture for rubber-like appearance
                                const textureNoise = (bumpRng() - 0.5) * 0.05;
                                const clampedHeight = Math.max(0, Math.min(1, finalHeight + textureNoise));

                                const grayValue = Math.floor(clampedHeight * 255);

                                data[index] = grayValue;     // R
                                data[index + 1] = grayValue; // G
                                data[index + 2] = grayValue; // B
                                data[index + 3] = 255;       // A
                            } else {
                                // Fallback neutral color
                                data[index] = 128;     // R
                                data[index + 1] = 128; // G
                                data[index + 2] = 128; // B
                                data[index + 3] = 255; // A
                            }
                        }
                    }

                    bumpCtx.putImageData(imageData, 0, 0);
                    return bumpCanvas;
                }, []);

                // Update tile texture when canvas changes
                useEffect(() => {
                    if (!tileSceneRef.current || !canvasRef.current || totalParts === 0) {
                        // Reset to default material when no parts
                        if (tileSceneRef.current) {
                            const { material, controls } = tileSceneRef.current;
                            material.map = null;
                            material.bumpMap = null;
                            material.normalMap = null;
                            material.color.setHex(0xfafafa);
                            material.needsUpdate = true;
                            
                            // Force a render update
                            if (controls) {
                                controls.update();
                            }
                        }
                        return;
                    }

                    setTileLoading(true);

                    // Small delay to ensure canvas is updated
                    setTimeout(() => {
                        try {
                            // Use mixer canvas directly for vibrant, accurate colors
                            if (!canvasRef.current) {
                                setTileLoading(false);
                                return;
                            }

                            // Create enhanced version of mixer canvas for tile
                            const tileCanvas = document.createElement('canvas');
                            const tileCtx = tileCanvas.getContext('2d');
                            tileCanvas.width = 512;
                            tileCanvas.height = 512;

                            // Get mixer canvas dimensions to preserve aspect ratio
                            const mixerWidth = canvasRef.current.width;
                            const mixerHeight = canvasRef.current.height;
                            const mixerAspect = mixerWidth / mixerHeight;

                            // Get the largest square we can from the mixer canvas, then sample a portion for smaller granules
                            let sourceWidth, sourceHeight, sourceX, sourceY;

                            // Get the largest square from the center of the canvas
                            if (mixerAspect > 1) {
                                sourceWidth = sourceHeight = mixerHeight;
                                sourceX = (mixerWidth - sourceWidth) / 2;
                                sourceY = 0;
                            } else if (mixerAspect < 1) {
                                sourceWidth = sourceHeight = mixerWidth;
                                sourceX = 0;
                                sourceY = (mixerHeight - sourceHeight) / 2;
                            } else {
                                sourceWidth = mixerWidth;
                                sourceHeight = mixerHeight;
                                sourceX = sourceY = 0;
                            }

                            // Use tiling approach for smaller granules
                            const sampleWidth = sourceWidth;
                            const sampleHeight = sourceHeight;
                            const sampleX = sourceX;
                            const sampleY = sourceY;

                            // Apply saturation boost filter
                            tileCtx.filter = 'saturate(1.4) contrast(1.15) brightness(1.05)';

                            // Create 2x2 tiled pattern for smaller granules
                            const tileSize = 256; // Each tile is 256px (half of 512)
                            for (let x = 0; x < 2; x++) {
                                for (let y = 0; y < 2; y++) {
                                    tileCtx.drawImage(
                                        canvasRef.current,
                                        sampleX, sampleY, sampleWidth, sampleHeight,
                                        x * tileSize, y * tileSize, tileSize, tileSize
                                    );
                                }
                            }
                            tileCtx.filter = 'none';

                            // Create main texture with realistic granule surface
                            const texture = new THREE.CanvasTexture(tileCanvas);
                            texture.wrapS = THREE.RepeatWrapping;
                            texture.wrapT = THREE.RepeatWrapping;
                            texture.repeat.set(1, 1); // Single tile since we generate realistic surface at full resolution
                            texture.magFilter = THREE.LinearFilter;
                            texture.minFilter = THREE.LinearMipMapLinearFilter;
                            texture.flipY = false; // Correct orientation for Three.js

                            // Create enhanced bump map from granule structure
                            const bumpCanvas = createEnhancedBumpMap(parts, 256);
                            const bumpTexture = new THREE.CanvasTexture(bumpCanvas);
                            bumpTexture.wrapS = THREE.RepeatWrapping;
                            bumpTexture.wrapT = THREE.RepeatWrapping;
                            bumpTexture.repeat.set(1, 1); // Match main texture
                            bumpTexture.flipY = false;

                            // Update material with properties optimized for enhanced texture colors
                            const { material } = tileSceneRef.current;
                            material.map = texture;
                            material.bumpMap = bumpTexture;
                            material.bumpScale = 0.06; // Reduced bump to let colors show through
                            material.roughness = 0.8; // Slightly rough for realistic TPV
                            material.metalness = 0.0; // No metalness for pure color representation
                            material.color.setHex(0xffffff); // Let enhanced texture handle all color

                            // Simplified material properties to preserve enhanced texture colors
                            material.envMapIntensity = 0.2; // Reduced to preserve texture vibrancy
                            material.clearcoat = 0.05; // Minimal clearcoat
                            material.clearcoatRoughness = 0.9; // Keep clearcoat matte

                            // Remove emissive - let enhanced texture provide the pop
                            material.emissive = new THREE.Color(0x000000);
                            material.emissiveIntensity = 0.0;

                            material.needsUpdate = true;

                            // Force a render update since texture has changed
                            if (tileSceneRef.current.controls) {
                                tileSceneRef.current.controls.update();
                            }

                            setTileLoading(false);
                        } catch (error) {
                            console.error('Texture update error:', error);
                            setTileLoading(false);
                        }
                    }, 100);
                }, [totalParts, parts, createTileSurface, createEnhancedBumpMap]);

                const resetTileView = useCallback(() => {
                    if (tileSceneRef.current) {
                        const { camera, controls, tile } = tileSceneRef.current;
                        camera.position.set(300, 200, 300);
                        tile.rotation.set(0, 0, 0);
                        controls.reset();
                        controls.update(); // Ensure rendering happens
                        setTileZoomLevel(1); // Reset zoom level state
                    }
                }, []);

                // 3D Tile Zoom Functions
                const zoomIn3D = useCallback(() => {
                    if (tileSceneRef.current) {
                        const { camera, controls } = tileSceneRef.current;
                        const zoomFactor = 0.8; // Stronger zoom than mouse wheel

                        // Apply zoom by scaling
                        if (camera.position.length() * zoomFactor > 50) { // Minimum distance
                            camera.position.multiplyScalar(zoomFactor);
                            setTileZoomLevel(prev => Math.min(prev / zoomFactor, 4)); // Max 4x zoom
                            controls.update();
                        }
                    }
                }, []);

                const zoomOut3D = useCallback(() => {
                    if (tileSceneRef.current) {
                        const { camera, controls } = tileSceneRef.current;
                        const zoomFactor = 1.25; // Inverse of zoom in

                        // Apply zoom by scaling
                        if (camera.position.length() * zoomFactor < 800) { // Maximum distance
                            camera.position.multiplyScalar(zoomFactor);
                            setTileZoomLevel(prev => Math.max(prev / zoomFactor, 0.25)); // Min 0.25x zoom
                            controls.update();
                        }
                    }
                }, []);

                const resetZoom3D = useCallback(() => {
                    if (tileSceneRef.current) {
                        const { camera, controls } = tileSceneRef.current;
                        camera.position.set(300, 200, 300); // Reset to default position
                        setTileZoomLevel(1);
                        controls.update();
                    }
                }, []);

                // Double-tap zoom functionality
                const lastTapRef = useRef(0);
                const handleDoubleTap = useCallback((event) => {
                    const now = Date.now();
                    const timeSince = now - lastTapRef.current;
                    
                    if (timeSince < 300 && timeSince > 0) {
                        // Double tap detected
                        event.preventDefault();
                        zoomIn3D();
                    }
                    
                    lastTapRef.current = now;
                }, [zoomIn3D]);

                // Add double-click for desktop
                const handleDoubleClick = useCallback((event) => {
                    event.preventDefault();
                    zoomIn3D();
                }, [zoomIn3D]);

                return React.createElement('div', { className: 'tile-preview-section' },
                    React.createElement('h2', { className: 'palette-title' }, '3D Tile Preview'),
                    React.createElement('div', { 
                        className: 'tile-preview-container',
                        ref: tileContainerRef,
                        style: { position: 'relative' },
                        onTouchEnd: handleDoubleTap,
                        onDoubleClick: handleDoubleClick
                    },
                        tileLoading && React.createElement('div', { className: 'tile-preview-loading' }, 'Updating texture...'),
                        tileError && React.createElement('div', { className: 'tile-preview-error' }, tileError),
                        !tileError && React.createElement('div', { className: 'tile-zoom-controls' },
                            React.createElement('button', {
                                className: 'tile-zoom-btn',
                                onClick: zoomIn3D,
                                disabled: tileZoomLevel >= 4,
                                title: 'Zoom In',
                                'aria-label': 'Zoom In 3D Tile'
                            }, '+'),
                            React.createElement('button', {
                                className: 'tile-zoom-btn',
                                onClick: zoomOut3D,
                                disabled: tileZoomLevel <= 0.25,
                                title: 'Zoom Out',
                                'aria-label': 'Zoom Out 3D Tile'
                            }, '−'),
                            React.createElement('button', {
                                className: 'tile-zoom-btn',
                                onClick: resetZoom3D,
                                title: 'Reset Zoom',
                                'aria-label': 'Reset 3D Tile Zoom',
                                style: { fontSize: '14px' }
                            }, '↻')
                        )
                    ),
                    React.createElement('div', { className: 'tile-preview-controls' },
                        React.createElement('div', { className: 'tile-preview-info' },
                            React.createElement('span', null, '200×200×20mm tile • 1-4mm granules')
                        ),
                        React.createElement('button', {
                            className: 'tile-preview-reset',
                            onClick: resetTileView
                        }, 'Reset View')
                    )
                );
            }

            // Main App Component
            function App() {
                const canvasRef = useRef(null);
                const [isInitializing, setIsInitializing] = useState(true);
                const [parts, setParts] = useState(new Map());
                const [seed, setSeed] = useState(generateSeed());
                const [undoStack, setUndoStack] = useState([]);
                const [redoStack, setRedoStack] = useState([]);
                const [voronoiData, setVoronoiData] = useState(null);
                const [tooltip, setTooltip] = useState(null);
                const [zoomLevel, setZoomLevel] = useState(2);
                const [panOffset, setPanOffset] = useState({ x: 0, y: 0 });
                const [isPanning, setIsPanning] = useState(false);
                const [lastMousePos, setLastMousePos] = useState({ x: 0, y: 0 });
                const [projectDetails, setProjectDetails] = useState({
                    name: '',
                    location: '',
                    area: '',
                    depth: '',
                    notes: ''
                });
                const [shareInput, setShareInput] = useState('');
                const [shareError, setShareError] = useState('');

                const canvasWidth = 1000;
                const canvasHeight = 500;
                const exportWidth = 2000;
                const exportHeight = 1000;

                // Load mix code from URL parameters
                useEffect(() => {
                    const urlParams = new URLSearchParams(window.location.search);
                    const codeFromURL = urlParams.get('code');

                    if (codeFromURL) {
                        const code = codeFromURL.trim().toUpperCase();

                        if (code.length >= 8) {
                            try {
                                const seedPart = code.substring(0, 8).toLowerCase();
                                const recipePart = code.substring(8);
                                const newParts = decompressRecipe(recipePart);

                                setSeed(seedPart);
                                setParts(newParts);

                                // Show success notification
                                setTooltip({ text: 'Mix loaded from URL!', x: window.innerWidth / 2, y: 100 });
                                setTimeout(() => setTooltip(null), 2000);
                            } catch (error) {
                                setShareError('Invalid mix code in URL');
                            }
                        }
                    }
                }, []); // Run once on mount

                // Initialize Voronoi diagram
                useEffect(() => {
                    const initializeVoronoi = async () => {
                        setIsInitializing(true);
                        
                        // Generate points using seeded RNG
                        const seedNum = seed.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
                        const rng = mulberry32(seedNum);
                        
                        // Adjust minDistance for desired cell count (~50,000 cells) with clustering
                        const targetCells = 50000;
                        const area = canvasWidth * canvasHeight;
                        const baseMinDistance = Math.sqrt(area / targetCells) * 2;

                        // Reduce minimum distance to allow natural clustering (75% of calculated)
                        const minDistance = baseMinDistance * 0.75;
                        
                        // Variable maxTries for more natural distribution variation
                        const maxTries = 20 + Math.floor(rng() * 20); // 20-40 tries

                        const points = poissonDiskSampling(canvasWidth, canvasHeight, minDistance, maxTries, rng);
                        
                        // Add enhanced size variation to points (25% to 400% range)
                        const pointsWithSize = points.map(([x, y]) => {
                            // Weighted distribution favoring medium sizes
                            const rand1 = rng();
                            const rand2 = rng();
                            const rand3 = rng();

                            // Use multiple random values to create bell-curve-like distribution
                            const weightedRandom = (rand1 + rand2 + rand3) / 3;

                            // Map to 25%-400% range with bias toward center
                            const minSize = 0.25;
                            const maxSize = 4.0;
                            const range = maxSize - minSize;

                            // Apply exponential curve to favor medium sizes
                            const exponentialWeight = Math.pow(weightedRandom, 0.7);
                            const size = minSize + range * exponentialWeight;

                            return {
                                x,
                                y,
                                size: size
                            };
                        });
                        
                        // Create Voronoi diagram
                        const delaunay = d3.Delaunay.from(pointsWithSize, p => p.x, p => p.y);
                        const voronoi = delaunay.voronoi([0, 0, canvasWidth, canvasHeight]);
                        
                        setVoronoiData({
                            points: pointsWithSize,
                            voronoi,
                            delaunay,
                            cells: Array.from({ length: points.length }, (_, i) => ({
                                index: i,
                                colourIndex: -1,
                                polygon: [...voronoi.cellPolygon(i)]
                            }))
                        });
                        
                        setIsInitializing(false);
                    };

                    initializeVoronoi();
                }, [seed]);

                // Render canvas
                useEffect(() => {
                    if (!voronoiData || !canvasRef.current) return;

                    const canvas = canvasRef.current;
                    const ctx = canvas.getContext('2d');
                    canvas.width = canvasWidth;
                    canvas.height = canvasHeight;
                    
                    // Save the current state
                    ctx.save();
                    
                    // Apply zoom and pan transformations
                    ctx.translate(panOffset.x, panOffset.y);
                    ctx.scale(zoomLevel, zoomLevel);

                    // Clear canvas with light grey background
                    ctx.fillStyle = '#FAFAFA';
                    ctx.fillRect(0, 0, canvasWidth, canvasHeight);

                    // Calculate colour distribution
                    const totalParts = Array.from(parts.values()).reduce((a, b) => a + b, 0);
                    const cellAssignments = new Array(voronoiData.cells.length).fill(-1);
                    
                    if (totalParts > 0) {
                        // Create shuffled indices using seed
                        const seedNum = (seed + totalParts).split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
                        const rng = mulberry32(seedNum);
                        const indices = Array.from({ length: voronoiData.cells.length }, (_, i) => i);
                        
                        // Fisher-Yates shuffle
                        for (let i = indices.length - 1; i > 0; i--) {
                            const j = Math.floor(rng() * (i + 1));
                            [indices[i], indices[j]] = [indices[j], indices[i]];
                        }

                        // Assign colours based on parts
                        let cursor = 0;
                        parts.forEach((partCount, colourIndex) => {
                            const quota = Math.round((partCount / totalParts) * indices.length);
                            for (let i = 0; i < quota && cursor < indices.length; i++) {
                                cellAssignments[indices[cursor]] = colourIndex;
                                cursor++;
                            }
                        });
                    } else {
                        // If no parts selected, show white granules (no color assigned)
                        for (let i = 0; i < cellAssignments.length; i++) {
                            cellAssignments[i] = -1; // No color assigned (white)
                        }
                    }

                    // First pass: Draw all cells without strokes to ensure complete coverage
                    voronoiData.cells.forEach((cell, i) => {
                        const polygon = cell.polygon;
                        if (!polygon || polygon.length < 3) return;

                        const colourIndex = cellAssignments[i];
                        const baseColour = colourIndex === -1 ? { hex: '#FAFAFA' } : PALETTE[colourIndex];

                        // Add color variation effects (saturation, hue shifting, edge bleeding)
                        const variationRng = mulberry32(Math.floor(voronoiData.points[i].x + voronoiData.points[i].y * 1000));

                        let finalColor = baseColour.hex;
                        if (colourIndex !== -1) {
                            // Parse base color
                            const r = parseInt(baseColour.hex.slice(1, 3), 16);
                            const g = parseInt(baseColour.hex.slice(3, 5), 16);
                            const b = parseInt(baseColour.hex.slice(5, 7), 16);

                            // Convert to HSL for better manipulation
                            const hsl = rgbToHsl(r, g, b);

                            // More subtle saturation variation (±5%)
                            const satVariation = (variationRng() - 0.5) * 0.1; // ±0.05
                            const newSat = Math.max(0, Math.min(1, hsl[1] + satVariation));

                            // Very minor hue shifting within color family (±2 degrees)
                            const hueVariation = (variationRng() - 0.5) * 4; // ±2 degrees
                            const newHue = (hsl[0] + hueVariation + 360) % 360;

                            // Minimal lightness variation (±3%)
                            const lightVariation = (variationRng() - 0.5) * 0.06; // ±0.03
                            let newLight = Math.max(0, Math.min(1, hsl[2] + lightVariation));

                            // Enhanced size-based hierarchy: contrast scaling
                            const granuleSize = voronoiData.points[i].size || 1;
                            const normalizedSize = Math.min(4, Math.max(0.25, granuleSize));

                            // Size-based contrast adjustment (larger = more vibrant, smaller = more muted)
                            const sizeContrastFactor = 0.7 + (normalizedSize / 4) * 0.6; // 0.7 to 1.3 range

                            // Apply contrast scaling to saturation and lightness
                            const contrastAdjustedSat = Math.max(0, Math.min(1, newSat * sizeContrastFactor));

                            // Small granules get slightly desaturated and pushed toward mid-tones
                            if (normalizedSize < 1.0) {
                                const muteFactor = (1.0 - normalizedSize) * 0.3; // Up to 30% muting for smallest
                                newLight = newLight + (0.5 - newLight) * muteFactor; // Push toward 50% lightness
                            }

                            // Convert back to RGB
                            const [newR, newG, newB] = hslToRgb(newHue / 360, contrastAdjustedSat, newLight);
                            finalColor = `rgb(${Math.round(newR)}, ${Math.round(newG)}, ${Math.round(newB)})`;
                        }

                        const colour = { hex: finalColor };
                        
                        // Draw cell with subtle edge curves for organic appearance
                        ctx.beginPath();
                        ctx.moveTo(polygon[0][0], polygon[0][1]);

                        // Add slight curves to edges based on granule size for more organic look
                        const granuleSize = voronoiData.points[i].size || 1;
                        const curveIntensity = Math.min(2, granuleSize * 0.5); // Scale curve with size

                        for (let j = 1; j < polygon.length; j++) {
                            const currentPoint = polygon[j];
                            const prevPoint = polygon[j - 1];

                            // Calculate edge length and add subtle curve if edge is long enough
                            const edgeLength = Math.sqrt(
                                Math.pow(currentPoint[0] - prevPoint[0], 2) +
                                Math.pow(currentPoint[1] - prevPoint[1], 2)
                            );

                            if (edgeLength > 15 && curveIntensity > 0.5) {
                                // Create deterministic curve based on edge position
                                const edgeSeed = Math.floor(prevPoint[0] + prevPoint[1] + currentPoint[0] + currentPoint[1]);
                                const edgeRng = mulberry32(edgeSeed);

                                // Calculate control point for quadratic curve
                                const midX = (prevPoint[0] + currentPoint[0]) / 2;
                                const midY = (prevPoint[1] + currentPoint[1]) / 2;

                                // Perpendicular offset for curve
                                const edgeVecX = currentPoint[0] - prevPoint[0];
                                const edgeVecY = currentPoint[1] - prevPoint[1];
                                const perpX = -edgeVecY / edgeLength;
                                const perpY = edgeVecX / edgeLength;

                                const curveOffset = (edgeRng() - 0.5) * curveIntensity;
                                const controlX = midX + perpX * curveOffset;
                                const controlY = midY + perpY * curveOffset;

                                ctx.quadraticCurveTo(controlX, controlY, currentPoint[0], currentPoint[1]);
                            } else {
                                ctx.lineTo(currentPoint[0], currentPoint[1]);
                            }
                        }
                        ctx.closePath();
                        
                        ctx.fillStyle = colour.hex;
                        ctx.fill();
                    });

                    // Second pass: Add 3D effects only for colored cells
                    voronoiData.cells.forEach((cell, i) => {
                        const colourIndex = cellAssignments[i];
                        if (colourIndex === -1) return; // Skip unassigned cells (white)

                        const polygon = cell.polygon;
                        if (!polygon || polygon.length < 3) return;

                        // Apply same color variation as first pass
                        const baseColour = PALETTE[colourIndex];
                        const variationRng = mulberry32(Math.floor(voronoiData.points[i].x + voronoiData.points[i].y * 1000));

                        // Parse base color
                        const r = parseInt(baseColour.hex.slice(1, 3), 16);
                        const g = parseInt(baseColour.hex.slice(3, 5), 16);
                        const b = parseInt(baseColour.hex.slice(5, 7), 16);

                        // Convert to HSL for better manipulation
                        const hsl = rgbToHsl(r, g, b);

                        // More subtle saturation variation (±5%)
                        const satVariation = (variationRng() - 0.5) * 0.1;
                        const newSat = Math.max(0, Math.min(1, hsl[1] + satVariation));

                        // Very minor hue shifting within color family (±2 degrees)
                        const hueVariation = (variationRng() - 0.5) * 4;
                        const newHue = (hsl[0] + hueVariation + 360) % 360;

                        // Minimal lightness variation (±3%)
                        const lightVariation = (variationRng() - 0.5) * 0.06;
                        let newLight = Math.max(0, Math.min(1, hsl[2] + lightVariation));

                        // Convert back to RGB with base variations first
                        const [newR, newG, newB] = hslToRgb(newHue / 360, newSat, newLight);
                        const colour = {
                            hex: `rgb(${Math.round(newR)}, ${Math.round(newG)}, ${Math.round(newB)})`,
                            r: Math.round(newR),
                            g: Math.round(newG),
                            b: Math.round(newB)
                        };
                        
                        // Calculate cell center
                        let centerX = 0, centerY = 0;
                        for (let j = 0; j < polygon.length; j++) {
                            centerX += polygon[j][0];
                            centerY += polygon[j][1];
                        }
                        centerX /= polygon.length;
                        centerY /= polygon.length;

                        // Create edge-based shading for realistic 3D effect
                        const granuleSize = voronoiData.points[i].size || 1;

                        // Enhanced size-based hierarchy: apply contrast scaling to existing color
                        const normalizedSize = Math.min(4, Math.max(0.25, granuleSize));
                        const sizeContrastFactor = 0.7 + (normalizedSize / 4) * 0.6;

                        // Re-apply size-based contrast to the color
                        let finalR = colour.r;
                        let finalG = colour.g;
                        let finalB = colour.b;

                        if (colourIndex !== -1) {
                            // Convert current color back to HSL for contrast adjustment
                            const currentHsl = rgbToHsl(finalR, finalG, finalB);
                            const contrastAdjustedSat = Math.max(0, Math.min(1, currentHsl[1] * sizeContrastFactor));
                            let adjustedLight = currentHsl[2];

                            // Small granules get muted
                            if (normalizedSize < 1.0) {
                                const muteFactor = (1.0 - normalizedSize) * 0.3;
                                adjustedLight = adjustedLight + (0.5 - adjustedLight) * muteFactor;
                            }

                            // Convert back to RGB
                            const [adjustedR, adjustedG, adjustedB] = hslToRgb(currentHsl[0] / 360, contrastAdjustedSat, adjustedLight);
                            finalR = Math.round(adjustedR);
                            finalG = Math.round(adjustedG);
                            finalB = Math.round(adjustedB);

                            // Update colour object
                            colour.r = finalR;
                            colour.g = finalG;
                            colour.b = finalB;
                            colour.hex = `rgb(${finalR}, ${finalG}, ${finalB})`;
                        }

                        // Multiple light sources for enhanced realism
                        const primaryLight = { x: -0.7071, y: -0.7071, intensity: 0.8 }; // Main top-left light
                        const rimLight = { x: 0.5, y: -0.8, intensity: 0.3 }; // Rim light from top-right
                        const ambientLight = 0.2; // Base ambient lighting

                        // Calculate polygon lighting zones based on edge orientations
                        let totalLighting = 0;
                        let lightedArea = 0;
                        let maxLightIntensity = 0; // For specular highlights

                        for (let j = 0; j < polygon.length; j++) {
                            const p1 = polygon[j];
                            const p2 = polygon[(j + 1) % polygon.length];

                            // Calculate edge vector and normal
                            const edgeVec = { x: p2[0] - p1[0], y: p2[1] - p1[1] };
                            const edgeLength = Math.sqrt(edgeVec.x * edgeVec.x + edgeVec.y * edgeVec.y);

                            // Skip degenerate edges (zero length)
                            if (edgeLength < 0.001) continue;

                            // Calculate edge normal (perpendicular, pointing inward)
                            const normal = {
                                x: -edgeVec.y / edgeLength,
                                y: edgeVec.x / edgeLength
                            };

                            // Calculate lighting from primary light source
                            const primaryIntensity = Math.max(0, -(normal.x * primaryLight.x + normal.y * primaryLight.y)) * primaryLight.intensity;

                            // Calculate lighting from rim light source
                            const rimIntensity = Math.max(0, -(normal.x * rimLight.x + normal.y * rimLight.y)) * rimLight.intensity;

                            // Combine lighting sources
                            const combinedIntensity = Math.min(1, primaryIntensity + rimIntensity + ambientLight);

                            // Track maximum for specular highlights
                            maxLightIntensity = Math.max(maxLightIntensity, combinedIntensity);

                            totalLighting += combinedIntensity * edgeLength;
                            lightedArea += edgeLength;
                        }

                        // Calculate average lighting for this polygon with fallback
                        const avgLighting = lightedArea > 0 ? totalLighting / lightedArea : 0.5;

                        // Add ambient occlusion based on granule density
                        const cellDensity = Math.min(1, granuleSize / 2); // Larger granules create more occlusion
                        const ambientOcclusion = 1 - (cellDensity * 0.15); // Up to 15% darkening
                        
                        // Enhanced size-based lighting with ambient occlusion (use existing normalizedSize)
                        const sizeFactor = 0.4 + (normalizedSize / 4) * 1.2;

                        // Apply ambient occlusion to lighting
                        const occludedLighting = avgLighting * ambientOcclusion;
                        const lightingIntensity = Math.min(1, Math.max(0, occludedLighting * sizeFactor));

                        // Enhanced shadow depth with ambient occlusion
                        const shadowDepthMultiplier = (1 + (normalizedSize / 4) * 0.5) * (2 - ambientOcclusion);

                        // Specular highlights for larger granules with high light intensity
                        const specularThreshold = 0.7;
                        const hasSpecular = normalizedSize > 1.5 && maxLightIntensity > specularThreshold;
                        const specularIntensity = hasSpecular ? (maxLightIntensity - specularThreshold) * 2 : 0;
                        
                        // Calculate bounds for gradient positioning
                        let minX = polygon[0][0], maxX = polygon[0][0];
                        let minY = polygon[0][1], maxY = polygon[0][1];
                        for (let j = 1; j < polygon.length; j++) {
                            minX = Math.min(minX, polygon[j][0]);
                            maxX = Math.max(maxX, polygon[j][0]);
                            minY = Math.min(minY, polygon[j][1]);
                            maxY = Math.max(maxY, polygon[j][1]);
                        }
                        
                        // Ensure valid gradient coordinates
                        const gradientOffset = Math.max(1, (maxX - minX) * (0.2 + lightingIntensity * 0.3));
                        const gradientOffsetY = Math.max(1, (maxY - minY) * (0.2 + lightingIntensity * 0.3));
                        
                        // Create gradient based on edge lighting analysis with validation
                        const gradient = ctx.createLinearGradient(
                            minX + gradientOffset,
                            minY + gradientOffsetY,
                            maxX - gradientOffset,
                            maxY - gradientOffsetY
                        );
                        
                        // Use color values from variation (already available in colour object)
                        
                        // Enhanced gradient with specular highlights and improved lighting
                        const baseHighlightStrength = lightingIntensity * 25;
                        const baseShadowStrength = (1 - lightingIntensity) * 30;

                        // Apply size-based multipliers and specular enhancement
                        const highlightStrength = Math.floor(Math.max(0, Math.min(40, baseHighlightStrength * sizeFactor)));
                        const shadowStrength = Math.floor(Math.max(0, Math.min(50, baseShadowStrength * shadowDepthMultiplier)));

                        // Specular highlight (bright white spots on highly lit large granules)
                        const specularBoost = Math.floor(specularIntensity * 80); // Bright white highlight

                        // Build gradient with enhanced lighting
                        if (hasSpecular) {
                            // Add specular highlight for shiny granules
                            gradient.addColorStop(0, `rgba(${Math.min(255, colour.r + highlightStrength + specularBoost)}, ${Math.min(255, colour.g + highlightStrength + specularBoost)}, ${Math.min(255, colour.b + highlightStrength + specularBoost)}, 1)`);
                            gradient.addColorStop(0.1, `rgba(${Math.min(255, colour.r + highlightStrength + specularBoost * 0.3)}, ${Math.min(255, colour.g + highlightStrength + specularBoost * 0.3)}, ${Math.min(255, colour.b + highlightStrength + specularBoost * 0.3)}, 1)`);
                            gradient.addColorStop(0.3, `rgba(${Math.min(255, colour.r + highlightStrength * 0.6)}, ${Math.min(255, colour.g + highlightStrength * 0.6)}, ${Math.min(255, colour.b + highlightStrength * 0.6)}, 1)`);
                        } else {
                            // Standard highlight without specular
                            gradient.addColorStop(0, `rgba(${Math.min(255, colour.r + highlightStrength)}, ${Math.min(255, colour.g + highlightStrength)}, ${Math.min(255, colour.b + highlightStrength)}, 1)`);
                            gradient.addColorStop(0.2, `rgba(${Math.min(255, colour.r + highlightStrength * 0.5)}, ${Math.min(255, colour.g + highlightStrength * 0.5)}, ${Math.min(255, colour.b + highlightStrength * 0.5)}, 1)`);
                        }

                        gradient.addColorStop(0.5, colour.hex);
                        gradient.addColorStop(0.75, `rgba(${Math.max(0, colour.r - shadowStrength * 0.5)}, ${Math.max(0, colour.g - shadowStrength * 0.5)}, ${Math.max(0, colour.b - shadowStrength * 0.5)}, 1)`);
                        gradient.addColorStop(1, `rgba(${Math.max(0, colour.r - shadowStrength)}, ${Math.max(0, colour.g - shadowStrength)}, ${Math.max(0, colour.b - shadowStrength)}, 1)`);

                        // Draw cell with gradient using same curve pattern
                        ctx.beginPath();
                        ctx.moveTo(polygon[0][0], polygon[0][1]);

                        // Apply same curve logic for consistency
                        const curveIntensity = Math.min(2, granuleSize * 0.5);

                        for (let j = 1; j < polygon.length; j++) {
                            const currentPoint = polygon[j];
                            const prevPoint = polygon[j - 1];

                            const edgeLength = Math.sqrt(
                                Math.pow(currentPoint[0] - prevPoint[0], 2) +
                                Math.pow(currentPoint[1] - prevPoint[1], 2)
                            );

                            if (edgeLength > 15 && curveIntensity > 0.5) {
                                const edgeSeed = Math.floor(prevPoint[0] + prevPoint[1] + currentPoint[0] + currentPoint[1]);
                                const edgeRng = mulberry32(edgeSeed);

                                const midX = (prevPoint[0] + currentPoint[0]) / 2;
                                const midY = (prevPoint[1] + currentPoint[1]) / 2;

                                const edgeVecX = currentPoint[0] - prevPoint[0];
                                const edgeVecY = currentPoint[1] - prevPoint[1];
                                const perpX = -edgeVecY / edgeLength;
                                const perpY = edgeVecX / edgeLength;

                                const curveOffset = (edgeRng() - 0.5) * curveIntensity;
                                const controlX = midX + perpX * curveOffset;
                                const controlY = midY + perpY * curveOffset;

                                ctx.quadraticCurveTo(controlX, controlY, currentPoint[0], currentPoint[1]);
                            } else {
                                ctx.lineTo(currentPoint[0], currentPoint[1]);
                            }
                        }
                        ctx.closePath();
                        
                        ctx.fillStyle = gradient;
                        ctx.fill();

                        // Simplified texture - no problematic white effects
                        if (normalizedSize > 1.2) { // Only larger granules get minimal texture
                            const textureRng = mulberry32(Math.floor(centerX + centerY * 1000));
                            const colorBrightness = (colour.r + colour.g + colour.b) / (3 * 255);
                            const isDarkColor = colorBrightness < 0.5;

                            // Very subtle texture only for dark colors to avoid discoloration
                            if (isDarkColor && normalizedSize > 2.0) {
                                const numTexturePoints = Math.floor(normalizedSize * 2); // Much reduced
                                ctx.fillStyle = `rgba(255, 255, 255, 0.015)`; // Very subtle

                                for (let t = 0; t < numTexturePoints; t++) {
                                    const texX = centerX + (textureRng() - 0.5) * (maxX - minX) * 0.3;
                                    const texY = centerY + (textureRng() - 0.5) * (maxY - minY) * 0.3;
                                    const texSize = textureRng() * 0.8 + 0.2;

                                    ctx.beginPath();
                                    ctx.arc(texX, texY, texSize, 0, Math.PI * 2);
                                    ctx.fill();
                                }
                            }
                        }
                    });

                    // Third pass: Add multi-layer depth illusion with inner granules
                    voronoiData.cells.forEach((cell, i) => {
                        const colourIndex = cellAssignments[i];
                        if (colourIndex === -1) return; // Skip unassigned cells

                        const polygon = cell.polygon;
                        if (!polygon || polygon.length < 3) return;

                        // Apply same color variation as other passes
                        const baseColour = PALETTE[colourIndex];
                        const variationRng = mulberry32(Math.floor(voronoiData.points[i].x + voronoiData.points[i].y * 1000));

                        // Parse base color and apply variations
                        const r = parseInt(baseColour.hex.slice(1, 3), 16);
                        const g = parseInt(baseColour.hex.slice(3, 5), 16);
                        const b = parseInt(baseColour.hex.slice(5, 7), 16);

                        const hsl = rgbToHsl(r, g, b);
                        const satVariation = (variationRng() - 0.5) * 0.1;
                        const newSat = Math.max(0, Math.min(1, hsl[1] + satVariation));
                        const hueVariation = (variationRng() - 0.5) * 4;
                        const newHue = (hsl[0] + hueVariation + 360) % 360;
                        const lightVariation = (variationRng() - 0.5) * 0.06;
                        let newLight = Math.max(0, Math.min(1, hsl[2] + lightVariation));

                        const [newR, newG, newB] = hslToRgb(newHue / 360, newSat, newLight);
                        const colour = {
                            hex: `rgb(${Math.round(newR)}, ${Math.round(newG)}, ${Math.round(newB)})`,
                            r: Math.round(newR),
                            g: Math.round(newG),
                            b: Math.round(newB)
                        };

                        const granuleSize = voronoiData.points[i].size || 1;
                        const normalizedSize = Math.min(4, Math.max(0.25, granuleSize));

                        // Enhanced size-based hierarchy: apply contrast scaling to depth colors
                        if (colourIndex !== -1) {
                            const sizeContrastFactor = 0.7 + (normalizedSize / 4) * 0.6;

                            // Convert current color back to HSL for contrast adjustment
                            const currentHsl = rgbToHsl(colour.r, colour.g, colour.b);
                            const contrastAdjustedSat = Math.max(0, Math.min(1, currentHsl[1] * sizeContrastFactor));
                            let adjustedLight = currentHsl[2];

                            // Small granules get muted
                            if (normalizedSize < 1.0) {
                                const muteFactor = (1.0 - normalizedSize) * 0.3;
                                adjustedLight = adjustedLight + (0.5 - adjustedLight) * muteFactor;
                            }

                            // Update colour with size-based adjustments
                            const [adjustedR, adjustedG, adjustedB] = hslToRgb(currentHsl[0] / 360, contrastAdjustedSat, adjustedLight);
                            colour.r = Math.round(adjustedR);
                            colour.g = Math.round(adjustedG);
                            colour.b = Math.round(adjustedB);
                            colour.hex = `rgb(${colour.r}, ${colour.g}, ${colour.b})`;
                        }

                        // Only add depth effects to larger granules
                        if (normalizedSize > 1.5) {
                            // Calculate polygon center and bounds
                            let cellCenterX = 0, cellCenterY = 0;
                            let minX = polygon[0][0], maxX = polygon[0][0];
                            let minY = polygon[0][1], maxY = polygon[0][1];

                            for (let j = 0; j < polygon.length; j++) {
                                cellCenterX += polygon[j][0];
                                cellCenterY += polygon[j][1];
                                minX = Math.min(minX, polygon[j][0]);
                                maxX = Math.max(maxX, polygon[j][0]);
                                minY = Math.min(minY, polygon[j][1]);
                                maxY = Math.max(maxY, polygon[j][1]);
                            }
                            cellCenterX /= polygon.length;
                            cellCenterY /= polygon.length;

                            const depthRng = mulberry32(Math.floor(cellCenterX * 100 + cellCenterY * 100 + i));

                            const cellWidth = maxX - minX;
                            const cellHeight = maxY - minY;

                            // Add 1-3 inner "granules" for depth layering
                            const numInnerGranules = 1 + Math.floor(depthRng() * 3); // 1-3 inner shapes

                            for (let layer = 0; layer < numInnerGranules; layer++) {
                                const layerDepth = (layer + 1) / (numInnerGranules + 1); // 0.25, 0.5, 0.75 etc
                                const innerSize = (0.3 + depthRng() * 0.4) * (1 - layerDepth * 0.3); // Smaller for deeper layers

                                // Position inner granule within bounds
                                const offsetX = (depthRng() - 0.5) * cellWidth * 0.4;
                                const offsetY = (depthRng() - 0.5) * cellHeight * 0.4;
                                const innerCenterX = cellCenterX + offsetX;
                                const innerCenterY = cellCenterY + offsetY;

                                // Create inner granule as ellipse for variety
                                const innerRadiusX = cellWidth * innerSize * 0.5;
                                const innerRadiusY = cellHeight * innerSize * 0.5;

                                // Color-aware depth variation using pre-computed values
                                const r = colour.r;
                                const g = colour.g;
                                const b = colour.b;

                                // Calculate color brightness to adjust depth effects
                                const colorBrightness = (r + g + b) / (3 * 255);
                                const isDarkColor = colorBrightness < 0.5;

                                // Much more subtle color variation, scaled by color darkness
                                const baseVariation = isDarkColor ? 10 : 5; // Dark colors can handle more variation
                                const depthVariation = (depthRng() - 0.5) * baseVariation; // ±5-10 variation

                                // Reduce brightness effect and make it color-aware
                                const layerBrightness = isDarkColor ?
                                    (1 - layerDepth * 0.15) : // Darker colors: subtle darkening
                                    (1 - layerDepth * 0.08);  // Light colors: minimal darkening

                                // Apply variations more carefully
                                const innerR = Math.max(0, Math.min(255, (r + depthVariation) * layerBrightness));
                                const innerG = Math.max(0, Math.min(255, (g + depthVariation) * layerBrightness));
                                const innerB = Math.max(0, Math.min(255, (b + depthVariation) * layerBrightness));

                                // Set clipping to current cell to maintain tessellation
                                ctx.save();
                                ctx.beginPath();
                                ctx.moveTo(polygon[0][0], polygon[0][1]);
                                for (let j = 1; j < polygon.length; j++) {
                                    ctx.lineTo(polygon[j][0], polygon[j][1]);
                                }
                                ctx.closePath();
                                ctx.clip();

                                // Color-aware opacity for cleaner light colors
                                const baseOpacity = isDarkColor ? 0.25 : 0.15; // Lower opacity for light colors
                                const opacity = baseOpacity - layerDepth * 0.05; // More subtle opacity reduction
                                ctx.fillStyle = `rgba(${Math.floor(innerR)}, ${Math.floor(innerG)}, ${Math.floor(innerB)}, ${opacity})`;

                                ctx.beginPath();
                                ctx.ellipse(innerCenterX, innerCenterY, innerRadiusX, innerRadiusY, depthRng() * Math.PI * 2, 0, Math.PI * 2);
                                ctx.fill();

                                ctx.restore();
                            }
                        }
                    });

                    // Fourth pass: Apply focus/blur effects for depth of field realism
                    voronoiData.cells.forEach((cell, i) => {
                        const colourIndex = cellAssignments[i];
                        if (colourIndex === -1) return; // Skip unassigned cells

                        const polygon = cell.polygon;
                        if (!polygon || polygon.length < 3) return;

                        const granuleSize = voronoiData.points[i].size || 1;
                        const normalizedSize = Math.min(4, Math.max(0.25, granuleSize));

                        // Apply blur to small granules for depth of field effect
                        if (normalizedSize < 1.2) {
                            // Calculate blur amount based on size (smaller = more blur)
                            const blurAmount = Math.max(0.8, (1.2 - normalizedSize) * 1.5);

                            // Apply blur filter
                            ctx.filter = `blur(${blurAmount}px)`;

                            // Set clipping to current cell to maintain tessellation
                            ctx.save();
                            ctx.beginPath();
                            ctx.moveTo(polygon[0][0], polygon[0][1]);
                            for (let j = 1; j < polygon.length; j++) {
                                ctx.lineTo(polygon[j][0], polygon[j][1]);
                            }
                            ctx.closePath();
                            ctx.clip();

                            // Get the current granule colors (matching the existing passes)
                            const baseColour = PALETTE[colourIndex];
                            const variationRng = mulberry32(Math.floor(voronoiData.points[i].x + voronoiData.points[i].y * 1000));

                            // Parse base color and apply same variations as other passes
                            const r = parseInt(baseColour.hex.slice(1, 3), 16);
                            const g = parseInt(baseColour.hex.slice(3, 5), 16);
                            const b = parseInt(baseColour.hex.slice(5, 7), 16);

                            const hsl = rgbToHsl(r, g, b);
                            const satVariation = (variationRng() - 0.5) * 0.1;
                            const newSat = Math.max(0, Math.min(1, hsl[1] + satVariation));
                            const hueVariation = (variationRng() - 0.5) * 4;
                            const newHue = (hsl[0] + hueVariation + 360) % 360;
                            const lightVariation = (variationRng() - 0.5) * 0.06;
                            let newLight = Math.max(0, Math.min(1, hsl[2] + lightVariation));

                            // Apply size-based contrast scaling
                            const sizeContrastFactor = 0.7 + (normalizedSize / 4) * 0.6;
                            const contrastAdjustedSat = Math.max(0, Math.min(1, newSat * sizeContrastFactor));

                            // Small granules get muted
                            if (normalizedSize < 1.0) {
                                const muteFactor = (1.0 - normalizedSize) * 0.3;
                                newLight = newLight + (0.5 - newLight) * muteFactor;
                            }

                            const [finalR, finalG, finalB] = hslToRgb(newHue / 360, contrastAdjustedSat, newLight);
                            const finalColor = `rgb(${Math.round(finalR)}, ${Math.round(finalG)}, ${Math.round(finalB)})`;

                            // Re-render the blurred granule
                            ctx.fillStyle = finalColor;
                            ctx.beginPath();
                            ctx.moveTo(polygon[0][0], polygon[0][1]);
                            for (let j = 1; j < polygon.length; j++) {
                                ctx.lineTo(polygon[j][0], polygon[j][1]);
                            }
                            ctx.closePath();
                            ctx.fill();

                            ctx.restore();
                        }
                    });

                    // Reset filter for any subsequent drawing
                    ctx.filter = 'none';

                    // Add instructional text for blank canvas
                    if (totalParts === 0) {
                        ctx.save();
                        ctx.setTransform(1, 0, 0, 1, 0, 0); // Reset transformations for text
                        ctx.fillStyle = '#999999';
                        ctx.font = '24px "Source Sans Pro", sans-serif';
                        ctx.textAlign = 'center';
                        ctx.textBaseline = 'middle';
                        ctx.fillText('Click colours below to add granules', canvasWidth / 2, canvasHeight / 2);
                        ctx.restore();
                    }
                    
                    // Restore the canvas state
                    ctx.restore();
                }, [voronoiData, parts, seed, zoomLevel, panOffset]);

                // Add part function
                const addPart = useCallback((colourIndex) => {
                    setUndoStack(prev => [...prev, new Map(parts)]);
                    setRedoStack([]);
                    setParts(prev => {
                        const newParts = new Map(prev);
                        newParts.set(colourIndex, (newParts.get(colourIndex) || 0) + 1);
                        return newParts;
                    });
                }, [parts]);

                // Remove part function
                const removePart = useCallback((colourIndex) => {
                    const currentParts = parts.get(colourIndex) || 0;
                    if (currentParts > 0) {
                        setUndoStack(prev => [...prev, new Map(parts)]);
                        setRedoStack([]);
                        setParts(prev => {
                            const newParts = new Map(prev);
                            if (currentParts === 1) {
                                newParts.delete(colourIndex);
                            } else {
                                newParts.set(colourIndex, currentParts - 1);
                            }
                            return newParts;
                        });
                    }
                }, [parts]);

                // Undo/Redo functions
                const undo = useCallback(() => {
                    if (undoStack.length === 0) return;
                    const newUndoStack = [...undoStack];
                    const previousState = newUndoStack.pop();
                    setUndoStack(newUndoStack);
                    setRedoStack(prev => [...prev, new Map(parts)]);
                    setParts(previousState);
                }, [undoStack, parts]);

                const redo = useCallback(() => {
                    if (redoStack.length === 0) return;
                    const newRedoStack = [...redoStack];
                    const nextState = newRedoStack.pop();
                    setRedoStack(newRedoStack);
                    setUndoStack(prev => [...prev, new Map(parts)]);
                    setParts(nextState);
                }, [redoStack, parts]);

                // Clear function
                const clear = useCallback(() => {
                    setUndoStack(prev => [...prev, new Map(parts)]);
                    setRedoStack([]);
                    setParts(new Map());
                }, [parts]);

                // Export function
                const exportPNG = useCallback(() => {
                    const exportCanvas = document.createElement('canvas');
                    exportCanvas.width = exportWidth;
                    exportCanvas.height = exportHeight;
                    const ctx = exportCanvas.getContext('2d');
                    
                    // Scale and draw current canvas to export canvas
                    ctx.drawImage(canvasRef.current, 0, 0, canvasWidth, canvasHeight, 0, 0, exportWidth, exportHeight);
                    
                    exportCanvas.toBlob((blob) => {
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url;
                        a.download = `granule-mix-${seed}.png`;
                        a.click();
                        URL.revokeObjectURL(url);
                    });
                }, [seed]);

                // Calculate percentages and blend color
                const totalParts = Array.from(parts.values()).reduce((a, b) => a + b, 0);
                const percentages = new Map();
                parts.forEach((count, colourIndex) => {
                    percentages.set(colourIndex, (count / totalParts) * 100);
                });

                // Calculate blended color
                const calculateBlendedColor = useCallback(() => {
                    if (totalParts === 0) return '#FFFFFF';
                    
                    let totalR = 0, totalG = 0, totalB = 0;
                    
                    parts.forEach((count, colourIndex) => {
                        const colour = PALETTE[colourIndex];
                        const weight = count / totalParts;
                        
                        // Parse hex color
                        const r = parseInt(colour.hex.slice(1, 3), 16);
                        const g = parseInt(colour.hex.slice(3, 5), 16);
                        const b = parseInt(colour.hex.slice(5, 7), 16);
                        
                        totalR += r * weight;
                        totalG += g * weight;
                        totalB += b * weight;
                    });
                    
                    // Convert back to hex
                    const toHex = (n) => {
                        const hex = Math.round(Math.max(0, Math.min(255, n))).toString(16);
                        return hex.length === 1 ? '0' + hex : hex;
                    };
                    
                    return '#' + toHex(totalR) + toHex(totalG) + toHex(totalB);
                }, [parts, totalParts]);

                const blendedColor = calculateBlendedColor();
                const blendedRgb = blendedColor !== '#FFFFFF' ? {
                    r: parseInt(blendedColor.slice(1, 3), 16),
                    g: parseInt(blendedColor.slice(3, 5), 16),
                    b: parseInt(blendedColor.slice(5, 7), 16)
                } : { r: 255, g: 255, b: 255 };

                // Get contrast color for text
                const getContrastColor = (hex) => {
                    const r = parseInt(hex.slice(1, 3), 16);
                    const g = parseInt(hex.slice(3, 5), 16);
                    const b = parseInt(hex.slice(5, 7), 16);
                    const brightness = (r * 299 + g * 587 + b * 114) / 1000;
                    return brightness > 128 ? '#000000' : '#FFFFFF';
                };

                // Generate compact share code
                const shareCode = useMemo(() => {
                    const compressedRecipe = compressRecipe(parts);
                    return `${seed.toUpperCase()}${compressedRecipe}`;
                }, [seed, parts]);

                // Copy to clipboard
                const copyShareCode = useCallback(() => {
                    navigator.clipboard.writeText(shareCode);
                    setTooltip({ text: 'Copied!', x: window.innerWidth / 2, y: 100 });
                    setTimeout(() => setTooltip(null), 2000);
                }, [shareCode]);

                // Generate shareable URL
                const getShareableURL = useCallback(() => {
                    const baseURL = window.location.origin + window.location.pathname;
                    return `${baseURL}?code=${shareCode}`;
                }, [shareCode]);

                // Copy URL to clipboard
                const copyShareURL = useCallback(() => {
                    const url = getShareableURL();
                    navigator.clipboard.writeText(url);
                    setTooltip({ text: 'Link copied!', x: window.innerWidth / 2, y: 100 });
                    setTimeout(() => setTooltip(null), 2000);
                }, [getShareableURL]);

                // Load share code
                const loadShareCode = useCallback(() => {
                    setShareError('');
                    
                    if (!shareInput.trim()) {
                        setShareError('Please enter a share code');
                        return;
                    }
                    
                    const code = shareInput.trim().toUpperCase();
                    
                    // Validate minimum length (8 char seed + at least 2 char recipe)
                    if (code.length < 8) {
                        setShareError('Invalid share code format');
                        return;
                    }
                    
                    try {
                        const seedPart = code.substring(0, 8).toLowerCase();
                        const recipePart = code.substring(8);
                        
                        const newParts = decompressRecipe(recipePart);
                        
                        // Save current state to undo stack
                        setUndoStack(prev => [...prev, new Map(parts)]);
                        setRedoStack([]);
                        
                        // Load new state
                        setSeed(seedPart);
                        setParts(newParts);
                        setShareInput('');
                        
                        setTooltip({ text: 'Mix loaded!', x: window.innerWidth / 2, y: 100 });
                        setTimeout(() => setTooltip(null), 2000);
                        
                    } catch (error) {
                        setShareError('Invalid share code format');
                    }
                }, [shareInput, parts]);

                // Helper function to constrain pan offset within bounds
                const constrainPanOffset = useCallback((offset, zoom) => {
                    const maxPanX = Math.max(0, (canvasWidth * zoom - canvasWidth) / 2);
                    const maxPanY = Math.max(0, (canvasHeight * zoom - canvasHeight) / 2);
                    
                    return {
                        x: Math.max(-maxPanX, Math.min(maxPanX, offset.x)),
                        y: Math.max(-maxPanY, Math.min(maxPanY, offset.y))
                    };
                }, []);

                // Zoom functions
                const zoomIn = useCallback(() => {
                    setZoomLevel(prev => {
                        const newZoom = Math.min(prev * 1.2, 5);
                        // Constrain pan offset for new zoom level
                        setPanOffset(currentOffset => constrainPanOffset(currentOffset, newZoom));
                        return newZoom;
                    });
                }, [constrainPanOffset]);

                const zoomOut = useCallback(() => {
                    setZoomLevel(prev => {
                        const newZoom = Math.max(prev / 1.2, 0.5);
                        // Constrain pan offset for new zoom level
                        setPanOffset(currentOffset => constrainPanOffset(currentOffset, newZoom));
                        return newZoom;
                    });
                }, [constrainPanOffset]);

                const resetCanvas = useCallback(() => {
                    // Clear all parts
                    setUndoStack(prev => [...prev, new Map(parts)]);
                    setRedoStack([]);
                    setParts(new Map());
                    // Reset zoom and pan
                    setZoomLevel(2);
                    setPanOffset({ x: 0, y: 0 });
                }, [parts]);

                // Calculate material requirements
                const calculateMaterial = useCallback((area, depth) => {
                    const areaNum = parseFloat(area);
                    const depthNum = parseFloat(depth);
                    if (isNaN(areaNum) || isNaN(depthNum) || areaNum <= 0 || depthNum <= 0) {
                        return 0;
                    }
                    
                    // Material density lookup table based on real installation data
                    const materialDensity = {
                        10: 9.0,    // 9kg/m² at 10mm depth
                        15: 14.5,   // 14.5kg/m² at 15mm depth
                        20: 18.0,   // 18kg/m² at 20mm depth
                        25: 23.5    // 23.5kg/m² at 25mm depth
                    };
                    
                    // Get density for exact depths or interpolate for custom depths
                    let densityPerM2;
                    if (materialDensity[depthNum]) {
                        densityPerM2 = materialDensity[depthNum];
                    } else {
                        // Linear interpolation for custom depths
                        const depths = Object.keys(materialDensity).map(Number).sort((a, b) => a - b);
                        
                        if (depthNum < depths[0]) {
                            // Extrapolate below minimum (use 10mm ratio)
                            densityPerM2 = (depthNum / 10) * materialDensity[10];
                        } else if (depthNum > depths[depths.length - 1]) {
                            // Extrapolate above maximum (use 25mm ratio)
                            densityPerM2 = (depthNum / 25) * materialDensity[25];
                        } else {
                            // Interpolate between known values
                            let lowerDepth = depths[0];
                            let upperDepth = depths[depths.length - 1];
                            
                            for (let i = 0; i < depths.length - 1; i++) {
                                if (depthNum >= depths[i] && depthNum <= depths[i + 1]) {
                                    lowerDepth = depths[i];
                                    upperDepth = depths[i + 1];
                                    break;
                                }
                            }
                            
                            const ratio = (depthNum - lowerDepth) / (upperDepth - lowerDepth);
                            densityPerM2 = materialDensity[lowerDepth] + 
                                          (materialDensity[upperDepth] - materialDensity[lowerDepth]) * ratio;
                        }
                    }
                    
                    return Math.round(areaNum * densityPerM2);
                }, []);

                const materialRequired = calculateMaterial(projectDetails.area, projectDetails.depth);

                // Calculate individual color material requirements
                const calculateColorMaterials = useCallback(() => {
                    if (totalParts === 0 || materialRequired === 0) return [];
                    
                    return Array.from(parts.entries()).map(([colorIndex, count]) => {
                        const color = PALETTE[colorIndex];
                        const percentage = (count / totalParts) * 100;
                        const quantity = Math.round((percentage / 100) * materialRequired);
                        
                        return {
                            colorIndex,
                            name: color.name,
                            code: color.code,
                            hex: color.hex,
                            percentage: Math.round(percentage),
                            quantity,
                            parts: count
                        };
                    }).sort((a, b) => b.quantity - a.quantity); // Sort by quantity descending
                }, [parts, totalParts, materialRequired]);

                const colorMaterials = calculateColorMaterials();

                // Generate PDF
                const generatePDF = useCallback(() => {
                    const { jsPDF } = window.jspdf;
                    const doc = new jsPDF();
                    
                    // Helper function to draw color swatch
                    const drawColorSwatch = (x, y, width, height, hexColor) => {
                        const r = parseInt(hexColor.slice(1, 3), 16);
                        const g = parseInt(hexColor.slice(3, 5), 16);
                        const b = parseInt(hexColor.slice(5, 7), 16);
                        doc.setFillColor(r, g, b);
                        doc.rect(x, y, width, height, 'F');
                        doc.setDrawColor(0, 0, 0);
                        doc.setLineWidth(0.1);
                        doc.rect(x, y, width, height, 'S');
                    };
                    
                    // Header with branding
                    doc.setFillColor(26, 54, 93); // Dark blue background
                    doc.rect(0, 0, 210, 35, 'F');
                    
                    doc.setTextColor(255, 255, 255);
                    doc.setFont('helvetica', 'normal');
                    doc.setFontSize(24);
                    doc.text('Rosehill TPV®', 20, 20);
                    
                    doc.setFont('helvetica', 'bold');
                    doc.setFontSize(18);
                    doc.text('Colour Mixer Report', 20, 30);
                    
                    // Orange accent stripe
                    doc.setFillColor(241, 91, 50);
                    doc.rect(0, 35, 210, 3, 'F');
                    
                    // Reset text color
                    doc.setTextColor(0, 0, 0);
                    let yPos = 55;
                    
                    // Project Details Section
                    doc.setFont('helvetica', 'bold');
                    doc.setFontSize(16);
                    doc.text('Project Details', 20, yPos);
                    yPos += 5;
                    
                    // Calculate the height needed for project details box
                    let projectDetailsHeight = 10; // Base padding
                    if (projectDetails.name) projectDetailsHeight += 8;
                    if (projectDetails.location) projectDetailsHeight += 8;
                    if (projectDetails.area) projectDetailsHeight += 8;
                    if (projectDetails.depth) projectDetailsHeight += 8;
                    projectDetailsHeight += 5; // Bottom padding
                    
                    // Light grey background for project details
                    doc.setFillColor(248, 249, 250);
                    doc.rect(20, yPos, 170, projectDetailsHeight, 'F');
                    doc.setDrawColor(233, 236, 239);
                    doc.setLineWidth(0.5);
                    doc.rect(20, yPos, 170, projectDetailsHeight, 'S');
                    
                    yPos += 10;
                    doc.setFont('helvetica', 'normal');
                    doc.setFontSize(11);
                    
                    if (projectDetails.name) {
                        doc.setFont('helvetica', 'bold');
                        doc.text('Project Name:', 25, yPos);
                        doc.setFont('helvetica', 'normal');
                        doc.text(projectDetails.name, 70, yPos);
                        yPos += 8;
                    }
                    if (projectDetails.location) {
                        doc.setFont('helvetica', 'bold');
                        doc.text('Location:', 25, yPos);
                        doc.setFont('helvetica', 'normal');
                        doc.text(projectDetails.location, 70, yPos);
                        yPos += 8;
                    }
                    if (projectDetails.area) {
                        doc.setFont('helvetica', 'bold');
                        doc.text('Area:', 25, yPos);
                        doc.setFont('helvetica', 'normal');
                        doc.text(`${projectDetails.area} m²`, 70, yPos);
                        yPos += 8;
                    }
                    if (projectDetails.depth) {
                        doc.setFont('helvetica', 'bold');
                        doc.text('Depth:', 25, yPos);
                        doc.setFont('helvetica', 'normal');
                        doc.text(`${projectDetails.depth} mm`, 70, yPos);
                        yPos += 8;
                    }
                    
                    yPos += 15; // Space after project details box
                    
                    // Mix Preview (moved to appear after project details)
                    if (totalParts > 0 && canvasRef.current) {
                        doc.setFont('helvetica', 'bold');
                        doc.setFontSize(16);
                        doc.text('Granular Mix Preview', 20, yPos);
                        yPos += 10;
                        
                        // Add canvas as image with border
                        const canvas = canvasRef.current;
                        const imgData = canvas.toDataURL('image/jpeg', 0.9);
                        
                        // Background for image
                        doc.setFillColor(255, 255, 255);
                        doc.rect(20, yPos, 170, 85, 'F');
                        doc.setDrawColor(233, 236, 239);
                        doc.setLineWidth(1);
                        doc.rect(20, yPos, 170, 85, 'S');
                        
                        doc.addImage(imgData, 'JPEG', 22, yPos + 2, 166, 81);
                        yPos += 100;
                    }
                    
                    // Colour Mix Section
                    if (totalParts > 0) {
                        if (yPos > 200) {
                            doc.addPage();
                            yPos = 20;
                        }
                        
                        doc.setFont('helvetica', 'bold');
                        doc.setFontSize(16);
                        doc.text('Colour Specification', 20, yPos);
                        yPos += 10;
                        
                        // Individual colours table header (moved before average blend)
                        doc.setFont('helvetica', 'bold');
                        doc.setFontSize(12);
                        doc.text('Colour Breakdown:', 20, yPos);
                        yPos += 8;
                        
                        // Table headers with Quantity column
                        doc.setFillColor(26, 54, 93);
                        doc.rect(20, yPos, 170, 8, 'F');
                        doc.setTextColor(255, 255, 255);
                        doc.setFont('helvetica', 'bold');
                        doc.setFontSize(10);
                        doc.text('Colour', 25, yPos + 5);
                        doc.text('Code', 60, yPos + 5);
                        doc.text('%', 85, yPos + 5);
                        doc.text('Parts', 105, yPos + 5);
                        doc.text('Quantity (kg)', 130, yPos + 5);
                        doc.text('Swatch', 165, yPos + 5);
                        yPos += 10;
                        
                        doc.setTextColor(0, 0, 0);
                        
                        // Color rows with quantity data
                        let rowIndex = 0;
                        Array.from(parts.entries()).forEach(([colourIndex, count]) => {
                            const colour = PALETTE[colourIndex];
                            const percentage = Math.round((count / totalParts) * 100);
                            const quantity = Math.round((percentage / 100) * materialRequired);
                            
                            // Alternating row background
                            if (rowIndex % 2 === 0) {
                                doc.setFillColor(248, 249, 250);
                                doc.rect(20, yPos - 2, 170, 8, 'F');
                            }
                            
                            doc.setFont('helvetica', 'normal');
                            doc.setFontSize(9);
                            doc.text(colour.name, 25, yPos + 3);
                            doc.text(colour.code, 60, yPos + 3);
                            doc.text(`${percentage}%`, 85, yPos + 3);
                            doc.text(count.toString(), 105, yPos + 3);
                            doc.text(`${quantity} kg`, 130, yPos + 3);
                            
                            // Color swatch
                            drawColorSwatch(165, yPos, 15, 5, colour.hex);
                            
                            yPos += 8;
                            rowIndex++;
                        });
                        
                        // Add border around table
                        doc.setDrawColor(233, 236, 239);
                        doc.setLineWidth(0.5);
                        doc.rect(20, yPos - (rowIndex * 8) - 10, 170, (rowIndex * 8) + 10, 'S');
                        
                        yPos += 10;
                        doc.setFont('helvetica', 'bold');
                        doc.setFontSize(11);
                        doc.text(`Total Parts: ${totalParts}`, 20, yPos);
                        yPos += 8;
                        doc.setTextColor(33, 150, 243);
                        doc.text(`Total Material Required: ${materialRequired} kg`, 20, yPos);
                        doc.setTextColor(0, 0, 0);
                        yPos += 20;
                        
                        // Average blend colour with large swatch (moved after breakdown)
                        doc.setFont('helvetica', 'bold');
                        doc.setFontSize(12);
                        doc.text('Average Blend Colour:', 20, yPos);
                        yPos += 5;
                        
                        // Large swatch for blended color
                        drawColorSwatch(20, yPos, 40, 20, blendedColor);
                        doc.setFont('helvetica', 'normal');
                        doc.setFontSize(11);
                        doc.text(blendedColor, 65, yPos + 8);
                        doc.text(`RGB(${blendedRgb.r}, ${blendedRgb.g}, ${blendedRgb.b})`, 65, yPos + 16);
                        yPos += 35;
                        
                        // Mix code section
                        doc.setFont('helvetica', 'bold');
                        doc.setFontSize(12);
                        doc.text('Mix Code:', 20, yPos);
                        yPos += 5;
                        
                        // Mix code background
                        doc.setFillColor(248, 249, 250);
                        doc.rect(20, yPos, 170, 15, 'F');
                        doc.setDrawColor(233, 236, 239);
                        doc.setLineWidth(0.5);
                        doc.rect(20, yPos, 170, 15, 'S');
                        
                        doc.setFont('helvetica', 'normal');
                        doc.setFontSize(14);
                        doc.setTextColor(33, 150, 243);
                        doc.text(shareCode, 25, yPos + 10);
                        doc.setTextColor(0, 0, 0);
                        yPos += 20;
                        
                        doc.setFont('helvetica', 'normal');
                        doc.setFontSize(9);
                        doc.setTextColor(102, 102, 102);
                        doc.text('Use this code in the Rosehill TPV® Colour Mixer to recreate this exact mix.', 20, yPos);
                        doc.setTextColor(0, 0, 0);
                        yPos += 10;
                    }
                    
                    // Notes Section
                    if (projectDetails.notes) {
                        if (yPos > 220) {
                            doc.addPage();
                            yPos = 20;
                        }
                        
                        doc.setFont('helvetica', 'bold');
                        doc.setFontSize(16);
                        doc.text('Project Notes', 20, yPos);
                        yPos += 10;
                        
                        // Notes background
                        const notesHeight = Math.max(30, projectDetails.notes.length / 8);
                        doc.setFillColor(248, 249, 250);
                        doc.rect(20, yPos, 170, notesHeight, 'F');
                        doc.setDrawColor(233, 236, 239);
                        doc.setLineWidth(0.5);
                        doc.rect(20, yPos, 170, notesHeight, 'S');
                        
                        yPos += 8;
                        doc.setFont('helvetica', 'normal');
                        doc.setFontSize(11);
                        const splitNotes = doc.splitTextToSize(projectDetails.notes, 160);
                        doc.text(splitNotes, 25, yPos);
                    }
                    
                    // Footer on all pages
                    const pageCount = doc.internal.getNumberOfPages();
                    for (let i = 1; i <= pageCount; i++) {
                        doc.setPage(i);
                        
                        // Footer background
                        doc.setFillColor(248, 249, 250);
                        doc.rect(0, 285, 210, 12, 'F');
                        
                        doc.setTextColor(102, 102, 102);
                        doc.setFont('helvetica', 'normal');
                        doc.setFontSize(9);
                        doc.text('Generated by Rosehill TPV® Colour Mixer', 20, 292);
                        doc.text(`Page ${i} of ${pageCount}`, 160, 292);
                        doc.text(new Date().toLocaleDateString('en-GB'), 20, 295);
                        
                        // Orange footer stripe
                        doc.setFillColor(241, 91, 50);
                        doc.rect(0, 297, 210, 1, 'F');
                    }
                    
                    // Save the PDF with British spelling
                    const currentDate = new Date().toISOString().split('T')[0]; // YYYY-MM-DD format
                    const fileName = projectDetails.name ? 
                        `${projectDetails.name.replace(/[^a-z0-9]/gi, '_').toLowerCase()}_colour_mix_${currentDate}.pdf` : 
                        `rosehill_tpv_colour_mix_${currentDate}.pdf`;
                    doc.save(fileName);
                }, [projectDetails, totalParts, parts, blendedColor, blendedRgb, materialRequired, colorMaterials, canvasRef]);

                // Mouse handlers for panning
                const handleMouseDown = useCallback((e) => {
                    if (e.button === 0) { // Left mouse button
                        setIsPanning(true);
                        setLastMousePos({ x: e.clientX, y: e.clientY });
                    }
                }, []);

                const handleMouseMove = useCallback((e) => {
                    if (isPanning) {
                        const dx = e.clientX - lastMousePos.x;
                        const dy = e.clientY - lastMousePos.y;
                        setPanOffset(prev => {
                            const newOffset = {
                                x: prev.x + dx,
                                y: prev.y + dy
                            };
                            return constrainPanOffset(newOffset, zoomLevel);
                        });
                        setLastMousePos({ x: e.clientX, y: e.clientY });
                    }
                }, [isPanning, lastMousePos, constrainPanOffset, zoomLevel]);

                const handleMouseUp = useCallback(() => {
                    setIsPanning(false);
                }, []);

                // Add mouse event listeners to canvas
                useEffect(() => {
                    const canvas = canvasRef.current;
                    if (!canvas) return;

                    canvas.addEventListener('mousedown', handleMouseDown);
                    window.addEventListener('mousemove', handleMouseMove);
                    window.addEventListener('mouseup', handleMouseUp);

                    return () => {
                        canvas.removeEventListener('mousedown', handleMouseDown);
                        window.removeEventListener('mousemove', handleMouseMove);
                        window.removeEventListener('mouseup', handleMouseUp);
                    };
                }, [handleMouseDown, handleMouseMove, handleMouseUp]);

                // Keyboard shortcuts
                useEffect(() => {
                    const handleKeyPress = (e) => {
                        if (e.ctrlKey || e.metaKey) {
                            if (e.key === 'z' && !e.shiftKey) {
                                e.preventDefault();
                                undo();
                            } else if ((e.key === 'z' && e.shiftKey) || e.key === 'y') {
                                e.preventDefault();
                                redo();
                            }
                        }
                    };
                    window.addEventListener('keydown', handleKeyPress);
                    return () => window.removeEventListener('keydown', handleKeyPress);
                }, [undo, redo]);

                return React.createElement('div', { className: 'app' },
                    React.createElement('div', { className: 'main-content' },
                        React.createElement('div', { className: 'canvas-container' },
                            React.createElement('div', { className: 'canvas-wrapper' },
                                React.createElement('canvas', { 
                                    ref: canvasRef,
                                    style: { cursor: isPanning ? 'grabbing' : 'grab' }
                                }),
                                React.createElement('div', { className: 'zoom-controls' },
                                    React.createElement('button', {
                                        className: 'zoom-btn',
                                        onClick: zoomIn,
                                        disabled: zoomLevel >= 5,
                                        title: 'Zoom In',
                                        'aria-label': 'Zoom In'
                                    }, '+'),
                                    React.createElement('button', {
                                        className: 'zoom-btn',
                                        onClick: zoomOut,
                                        disabled: zoomLevel <= 0.5,
                                        title: 'Zoom Out',
                                        'aria-label': 'Zoom Out'
                                    }, '−'),
                                    React.createElement('button', {
                                        className: 'zoom-btn',
                                        onClick: resetCanvas,
                                        disabled: parts.size === 0 && zoomLevel === 2 && panOffset.x === 0 && panOffset.y === 0,
                                        title: 'Reset Canvas',
                                        'aria-label': 'Reset Canvas',
                                        style: { fontSize: '14px' }
                                    }, '⟲')
                                ),
                                isInitializing && React.createElement('div', { className: 'loading-overlay' }, 'Generating granules...')
                            )
                        ),

                        React.createElement('div', { className: 'palette-section' },
                            React.createElement('h2', { className: 'palette-title' }, 'Colour Palette'),
                                React.createElement('div', { className: 'palette-grid' },
                                    PALETTE.map((colour, index) => {
                                        const partCount = parts.get(index) || 0;
                                        return React.createElement('div', {
                                            key: index,
                                            className: 'colour-item'
                                        },
                                            React.createElement('button', {
                                                className: 'colour-swatch' + (partCount > 0 ? ' has-parts' : ''),
                                                style: { backgroundColor: colour.hex },
                                                onClick: () => addPart(index),
                                                'aria-label': `Add ${colour.name}`,
                                                title: colour.name
                                            }),
                                            React.createElement('div', { className: 'colour-info' },
                                                React.createElement('div', { className: 'colour-name' }, colour.name),
                                                React.createElement('div', { className: 'colour-code' }, colour.code)
                                            ),
                                            React.createElement('div', { className: 'parts-controls' },
                                                React.createElement('button', {
                                                    className: 'parts-btn',
                                                    onClick: () => removePart(index),
                                                    disabled: partCount === 0,
                                                    'aria-label': `Remove ${colour.name}`
                                                }, '−'),
                                                React.createElement('div', { className: 'parts-count' }, partCount),
                                                React.createElement('button', {
                                                    className: 'parts-btn',
                                                    onClick: () => addPart(index),
                                                    'aria-label': `Add ${colour.name}`
                                                }, '+')
                                            )
                                        );
                                    })
                                )
                        ),

                        React.createElement('div', { className: 'controls' },
                            React.createElement('div', { className: 'left-controls' },
                                React.createElement('div', { className: 'mix-bar-section' },
                                React.createElement('h2', { className: 'palette-title' }, 'Current Mix'),
                                React.createElement('div', { className: 'mix-bar' },
                                    totalParts === 0 
                                        ? React.createElement('div', { className: 'mix-bar-segment mix-bar-empty' }, 'Empty canvas')
                                        : Array.from(percentages.entries()).map(([colourIndex, percentage]) =>
                                            React.createElement('div', {
                                                key: colourIndex,
                                                className: 'mix-bar-segment',
                                                style: {
                                                    backgroundColor: PALETTE[colourIndex].hex,
                                                    flexBasis: `${percentage}%`
                                                }
                                            }, percentage >= 10 && `${Math.round(percentage)}%`)
                                        )
                                ),
                                totalParts > 0 && React.createElement('div', { className: 'mix-details' },
                                    Array.from(parts.entries()).map(([colourIndex, count]) =>
                                        React.createElement('div', { key: colourIndex, className: 'mix-detail-item' },
                                            React.createElement('div', {
                                                className: 'mix-detail-colour',
                                                style: { backgroundColor: PALETTE[colourIndex].hex }
                                            }),
                                            React.createElement('span', { className: 'mix-detail-text' },
                                                `${PALETTE[colourIndex].name} (${PALETTE[colourIndex].code}): ${Math.round(percentages.get(colourIndex))}% (${count} ${count === 1 ? 'part' : 'parts'})`
                                            )
                                        )
                                    )
                                )
                            ),

                                React.createElement('div', { className: 'action-buttons' },
                                React.createElement('button', { className: 'btn', onClick: undo, disabled: undoStack.length === 0 }, 'Undo'),
                                React.createElement('button', { className: 'btn', onClick: redo, disabled: redoStack.length === 0 }, 'Redo'),
                                React.createElement('button', { className: 'btn btn-secondary', onClick: clear, disabled: parts.size === 0 }, 'Clear'),
                                React.createElement('button', { className: 'btn', onClick: exportPNG, disabled: parts.size === 0 }, 'Export PNG')
                                ),
                                
                                React.createElement('div', { className: 'project-details-section' },
                                    React.createElement('h2', { className: 'palette-title' }, 'Project Details'),
                                    React.createElement('div', { className: 'form-grid' },
                                        React.createElement('div', { className: 'form-field' },
                                            React.createElement('label', { className: 'form-label' }, 'Project Name'),
                                            React.createElement('input', {
                                                type: 'text',
                                                className: 'form-input',
                                                value: projectDetails.name,
                                                onChange: (e) => setProjectDetails(prev => ({ ...prev, name: e.target.value }))
                                            })
                                        ),
                                        React.createElement('div', { className: 'form-field' },
                                            React.createElement('label', { className: 'form-label' }, 'Location'),
                                            React.createElement('input', {
                                                type: 'text',
                                                className: 'form-input',
                                                value: projectDetails.location,
                                                onChange: (e) => setProjectDetails(prev => ({ ...prev, location: e.target.value }))
                                            })
                                        ),
                                        React.createElement('div', { className: 'form-field' },
                                            React.createElement('label', { className: 'form-label' }, 'Area (m²)'),
                                            React.createElement('input', {
                                                type: 'number',
                                                className: 'form-input',
                                                value: projectDetails.area,
                                                onChange: (e) => setProjectDetails(prev => ({ ...prev, area: e.target.value })),
                                                min: '0',
                                                step: '0.1'
                                            })
                                        ),
                                        React.createElement('div', { className: 'form-field' },
                                            React.createElement('label', { className: 'form-label' }, 'Depth (mm)'),
                                            React.createElement('select', {
                                                className: 'form-input',
                                                value: projectDetails.depth,
                                                onChange: (e) => setProjectDetails(prev => ({ ...prev, depth: e.target.value }))
                                            },
                                                React.createElement('option', { value: '' }, 'Select depth...'),
                                                React.createElement('option', { value: '10' }, '10mm'),
                                                React.createElement('option', { value: '15' }, '15mm'),
                                                React.createElement('option', { value: '20' }, '20mm'),
                                                React.createElement('option', { value: '25' }, '25mm')
                                            )
                                        ),
                                        React.createElement('div', { className: 'form-field full-width' },
                                            React.createElement('label', { className: 'form-label' }, 'Notes'),
                                            React.createElement('textarea', {
                                                className: 'form-textarea',
                                                value: projectDetails.notes,
                                                onChange: (e) => setProjectDetails(prev => ({ ...prev, notes: e.target.value })),
                                                placeholder: 'Additional project notes, specifications, or requirements...'
                                            })
                                        )
                                    ),
                                    materialRequired > 0 && React.createElement('div', { className: 'material-calc' },
                                        React.createElement('h4', null, 'Material Calculation'),
                                        totalParts > 0 && colorMaterials.length > 0 && React.createElement('div', { className: 'color-materials-breakdown' },
                                            colorMaterials.map(colorMaterial => 
                                                React.createElement('div', { 
                                                    key: colorMaterial.colorIndex,
                                                    className: 'color-material-item'
                                                },
                                                    React.createElement('div', { className: 'color-material-info' },
                                                        React.createElement('div', {
                                                            className: 'color-material-swatch',
                                                            style: { backgroundColor: colorMaterial.hex }
                                                        }),
                                                        React.createElement('span', { className: 'color-material-name' },
                                                            `${colorMaterial.name} (${colorMaterial.code})`
                                                        )
                                                    ),
                                                    React.createElement('div', null,
                                                        React.createElement('span', { className: 'color-material-quantity' },
                                                            `${colorMaterial.quantity} kg`
                                                        ),
                                                        React.createElement('span', { className: 'color-material-percentage' },
                                                            `(${colorMaterial.percentage}%)`
                                                        )
                                                    )
                                                )
                                            )
                                        ),
                                        React.createElement('div', { className: 'material-total' },
                                            `Total Required: ${materialRequired} kg`
                                        ),
                                        React.createElement('div', { style: { fontSize: '0.85rem', color: '#666', marginTop: '8px', textAlign: 'center' } },
                                            `Based on ${projectDetails.area}m² area at ${projectDetails.depth}mm depth`
                                        )
                                    ),
                                    React.createElement('button', {
                                        className: 'btn-pdf',
                                        onClick: generatePDF,
                                        disabled: !projectDetails.name && totalParts === 0
                                    }, '📄 Save as PDF')
                                )
                            ),
                            
                            React.createElement('div', { className: 'right-controls' },
                                React.createElement(TilePreview, {
                                    canvasRef: canvasRef,
                                    parts: parts,
                                    totalParts: totalParts
                                }),
                                totalParts > 0 && React.createElement('div', { className: 'blend-preview-section' },
                                    React.createElement('h2', { className: 'palette-title' }, 'Average Blend Colour'),
                                    React.createElement('div', {
                                        className: 'blend-preview-swatch',
                                        style: { 
                                            backgroundColor: blendedColor,
                                            color: getContrastColor(blendedColor)
                                        },
                                        onClick: () => {
                                            navigator.clipboard.writeText(blendedColor);
                                            setTooltip({ text: 'Colour copied!', x: window.innerWidth / 2, y: 100 });
                                            setTimeout(() => setTooltip(null), 2000);
                                        },
                                        title: 'Click to copy hex code'
                                    }, blendedColor),
                                    React.createElement('div', { className: 'blend-details' },
                                        React.createElement('div', { className: 'blend-detail-row' },
                                            React.createElement('span', { className: 'blend-detail-label' }, 'Hex:'),
                                            React.createElement('span', { className: 'blend-detail-value' }, blendedColor)
                                        ),
                                        React.createElement('div', { className: 'blend-detail-row' },
                                            React.createElement('span', { className: 'blend-detail-label' }, 'RGB:'),
                                            React.createElement('span', { className: 'blend-detail-value' }, 
                                                `rgb(${blendedRgb.r}, ${blendedRgb.g}, ${blendedRgb.b})`
                                            )
                                        ),
                                        React.createElement('div', { style: { 
                                            fontSize: '0.75rem', 
                                            color: '#666', 
                                            marginTop: '10px',
                                            fontStyle: 'italic',
                                            lineHeight: '1.3'
                                        }}, 
                                            'This shows the weighted average of all colours in the mix. Useful for quick colour matching.'
                                        )
                                    )
                                ),
                                React.createElement('div', { className: 'share-section' },
                                React.createElement('h2', { className: 'palette-title' }, 'Share Mix'),
                                React.createElement('div', { style: { marginBottom: '15px' } },
                                    React.createElement('label', { className: 'form-label', style: { marginBottom: '5px', display: 'block' } }, 'Your Mix Code'),
                                    React.createElement('input', {
                                        type: 'text',
                                        className: 'share-input',
                                        value: shareCode,
                                        readOnly: true,
                                        onClick: (e) => e.target.select(),
                                        style: { marginBottom: '5px' }
                                    }),
                                    React.createElement('div', { style: { display: 'flex', gap: '10px' } },
                                        React.createElement('button', { className: 'btn', onClick: copyShareCode }, 'Copy Code'),
                                        React.createElement('button', { className: 'btn', onClick: copyShareURL }, 'Copy Link')
                                    ),
                                    React.createElement('div', {
                                        style: {
                                            fontSize: '11px',
                                            color: '#666',
                                            marginTop: '8px',
                                            wordBreak: 'break-all',
                                            fontStyle: 'italic'
                                        }
                                    }, `Shareable link: ${getShareableURL()}`)
                                ),
                                React.createElement('div', null,
                                    React.createElement('label', { className: 'form-label', style: { marginBottom: '5px', display: 'block' } }, 'Load Mix Code'),
                                    React.createElement('div', { className: 'share-input-group' },
                                        React.createElement('input', {
                                            type: 'text',
                                            className: 'share-input share-input-field',
                                            value: shareInput,
                                            onChange: (e) => {
                                                setShareInput(e.target.value);
                                                setShareError('');
                                            },
                                            placeholder: 'Enter a mix code...',
                                            style: { marginBottom: shareError ? '5px' : '0' }
                                        }),
                                        React.createElement('button', {
                                            className: 'btn btn-load',
                                            onClick: loadShareCode,
                                            disabled: !shareInput.trim()
                                        }, 'Load')
                                    ),
                                    shareError && React.createElement('div', { className: 'share-error' }, shareError)
                                )
                                )
                            )
                        )
                    ),

                    tooltip && React.createElement('div', {
                        className: 'tooltip',
                        style: {
                            left: tooltip.x + 'px',
                            top: tooltip.y + 'px',
                            transform: 'translate(-50%, -50%)'
                        }
                    }, tooltip.text)
                );
            }

            // Render the app
            ReactDOM.render(React.createElement(App), container);
    }

})();
